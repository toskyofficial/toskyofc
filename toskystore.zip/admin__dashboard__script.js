const API = {
    statistics: "/api/admin/statistics",
    products: "/api/admin/product/list"
};

const tokenKey = "fydzstore_admin_token";
const emailKey = "fydzstore_admin_email";
const roleKey = "fydzstore_admin_role";

const token = sessionStorage.getItem(tokenKey) || localStorage.getItem(tokenKey);

if (token) sessionStorage.setItem(tokenKey, token);


const adminEmail =
    sessionStorage.getItem(emailKey) || localStorage.getItem(emailKey) || "-";
const adminRole = sessionStorage.getItem(roleKey) || localStorage.getItem(roleKey) || "admin";

document.getElementById("adminEmail").textContent =
    adminEmail;

document.getElementById("adminAvatar").textContent =
    adminEmail.charAt(0).toUpperCase();

const roleBadge = document.querySelector(".admin-name");
if (roleBadge) roleBadge.textContent = adminRole === "developer" ? "Developer" : "Administrator";
const maintenanceNav = document.getElementById("maintenanceNav");
if (maintenanceNav && adminRole === "developer") maintenanceNav.style.display = "flex";


const elements = {
    loading: document.getElementById("loadingOverlay"),
    refresh: document.getElementById("refreshButton"),

    totalProducts: document.getElementById("totalProducts"),
    hostingProducts: document.getElementById("hostingProducts"),
    digitalProducts: document.getElementById("digitalProducts"),
    jasaProducts: document.getElementById("jasaProducts"),

    bars: document.getElementById("bars"),
    chartEmpty: document.getElementById("chartEmpty"),

    categoryList: document.getElementById("categoryList"),
    productsList: document.getElementById("productsList"),
    productCount: document.getElementById("productCount")
};


/* =========================
   AUTH
========================= */

function authHeaders() {
    return {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
    };
}


async function request(url) {
    const response = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: token ? authHeaders() : {}
    });

    if (
        response.status === 401 ||
        response.status === 403
    ) {
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);

        window.location.href = "/admin/";

        throw new Error(
            "Sesi admin sudah tidak valid."
        );
    }

    let data = null;

    try {
        data = await response.json();
    } catch {
        data = null;
    }

    if (!response.ok) {
        throw new Error(
            data?.message ||
            data?.error ||
            `Request gagal (${response.status})`
        );
    }

    return data;
}


/* =========================
   HELPERS
========================= */

function extractArray(data) {
    if (Array.isArray(data)) {
        return data;
    }

    if (Array.isArray(data?.data)) {
        return data.data;
    }

    if (Array.isArray(data?.products)) {
        return data.products;
    }

    if (Array.isArray(data?.data?.products)) {
        return data.data.products;
    }

    return [];
}


function number(value) {
    const parsed = Number(value);

    if (!Number.isFinite(parsed)) {
        return 0;
    }

    return parsed;
}


function formatNumber(value) {
    return number(value).toLocaleString("id-ID");
}


function formatPrice(value) {
    return (
        "Rp " +
        number(value).toLocaleString("id-ID")
    );
}


function normalizeMediaUrl(url) {
    if (!url) {
        return "/assets__fydz-logo.svg";
    }

    if (/^https?:\/\//i.test(url)) {
        return url;
    }

    return url.startsWith("/")
        ? url
        : "/" + url;
}


function getThumbnail(product) {
    return normalizeMediaUrl(
        product?.thumbnailProduct ||
        product?.thumbnail ||
        product?.image ||
        product?.thumbnailUrl
    );
}


function getCategory(product) {
    return String(
        product?.category || "lainnya"
    ).toLowerCase();
}


function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}


function escapeAttribute(value) {
    return escapeHTML(value);
}


/* =========================
   PRODUCTS
========================= */

async function loadProducts() {
    const response =
        await request(API.products);

    const products =
        extractArray(response);

    renderProductStats(products);
    renderCategories(products);
    renderLatestProducts(products);

    return products;
}


function renderProductStats(products) {
    const hosting =
        products.filter(
            product =>
                getCategory(product) === "hosting"
        ).length;

    const digital =
        products.filter(
            product =>
                getCategory(product) === "digital"
        ).length;

    const jasa =
        products.filter(
            product =>
                getCategory(product) === "jasa"
        ).length;

    elements.totalProducts.textContent =
        formatNumber(products.length);

    elements.hostingProducts.textContent =
        formatNumber(hosting);

    elements.digitalProducts.textContent =
        formatNumber(digital);

    elements.jasaProducts.textContent =
        formatNumber(jasa);
}


function renderCategories(products) {
    const categories = {};

    products.forEach(product => {
        const category =
            getCategory(product);

        categories[category] =
            (categories[category] || 0) + 1;
    });

    const sorted =
        Object.entries(categories)
            .sort((a, b) => b[1] - a[1]);

    if (!sorted.length) {
        elements.categoryList.innerHTML = `
            <div class="empty-products">
                Belum ada produk.
            </div>
        `;

        return;
    }

    const total =
        products.length || 1;

    elements.categoryList.innerHTML =
        sorted
            .map(([category, count]) => {

                const percentage =
                    Math.round(
                        (count / total) * 100
                    );

                return `
                    <div class="category-row">

                        <div class="category-head">

                            <span class="category-name">
                                ${escapeHTML(category)}
                            </span>

                            <span class="category-value">
                                ${formatNumber(count)} produk
                            </span>

                        </div>

                        <div class="progress">

                            <div
                                class="progress-bar"
                                style="width:${percentage}%"
                            ></div>

                        </div>

                    </div>
                `;

            })
            .join("");
}


function renderLatestProducts(products) {
    const sorted =
        [...products]
            .sort((a, b) => {

                const dateA =
                    new Date(
                        a.createdAt || 0
                    ).getTime();

                const dateB =
                    new Date(
                        b.createdAt || 0
                    ).getTime();

                return dateB - dateA;
            })
            .slice(0, 6);

    elements.productCount.textContent =
        `${formatNumber(products.length)} produk`;

    if (!sorted.length) {
        elements.productsList.innerHTML = `
            <div class="empty-products">
                Belum ada produk.
            </div>
        `;

        return;
    }

    elements.productsList.innerHTML =
        sorted
            .map(product => {

                return `
                    <div class="product-row">

                        <img
                            class="product-image"
                            src="${escapeAttribute(
                                getThumbnail(product)
                            )}"
                            alt="${escapeAttribute(
                                product.name ||
                                "Produk"
                            )}"
                            onerror="
                                this.src='/assets__fydz-logo.svg'
                            "
                        >

                        <div class="product-info">

                            <div class="product-name">
                                ${escapeHTML(
                                    product.name ||
                                    "Tanpa nama"
                                )}
                            </div>

                            <div class="product-category">
                                ${escapeHTML(
                                    getCategory(product)
                                )}
                            </div>

                        </div>

                        <div class="product-price">
                            ${formatPrice(
                                product.price
                            )}
                        </div>

                    </div>
                `;

            })
            .join("");
}


/* =========================
   STATISTICS
========================= */

async function loadStatistics() {
    const response =
        await request(API.statistics);

    console.log(
        "[FYDZSTORE STATISTICS]",
        response
    );

    if (!response?.success) {
        throw new Error(
            response?.error ||
            "Data statistik tidak valid."
        );
    }

    const visitors =
        response.visitors || {};

    const pages =
        Array.isArray(response.pages)
            ? response.pages
            : [];

    const daily =
        Array.isArray(response.daily)
            ? response.daily
            : [];

    console.log(
        "[STATISTICS VISITORS]",
        visitors
    );

    console.log(
        "[STATISTICS PAGES]",
        pages
    );

    console.log(
        "[STATISTICS DAILY]",
        daily
    );

    /*
     * Grafik utama:
     * jumlah kunjungan per hari.
     */
    renderStatisticsChart(daily);
}


/* =========================
   LINE CHART
========================= */

function renderStatisticsChart(daily) {
    elements.bars.innerHTML = "";

    if (!Array.isArray(daily) || !daily.length) {
        elements.chartEmpty.style.display =
            "grid";

        return;
    }

    elements.chartEmpty.style.display =
        "none";


    /*
     * =========================
     * CHART SIZE
     * =========================
     */

    const width = 900;
    const height = 320;

    const paddingLeft = 55;
    const paddingRight = 25;
    const paddingTop = 25;
    const paddingBottom = 50;

    const chartWidth =
        width -
        paddingLeft -
        paddingRight;

    const chartHeight =
        height -
        paddingTop -
        paddingBottom;


    /*
     * =========================
     * DATA
     * =========================
     */

    const values =
        daily.map(item =>
            number(item?.visits)
        );

    const maxValue =
        Math.max(
            ...values,
            1
        );


    /*
     * =========================
     * POINTS
     * =========================
     */

    const points =
        daily.map((item, index) => {

            const x =
                daily.length === 1
                    ? paddingLeft +
                      chartWidth / 2
                    : paddingLeft +
                      (
                          index /
                          (daily.length - 1)
                      ) *
                      chartWidth;

            const value =
                number(item?.visits);

            const y =
                paddingTop +
                chartHeight -
                (
                    value /
                    maxValue
                ) *
                chartHeight;

            return {
                x,
                y,
                value,
                date: item?.date || ""
            };
        });


    /*
     * =========================
     * LINE PATH
     * =========================
     */

    const linePath =
        points
            .map(
                (point, index) =>
                    `${index === 0 ? "M" : "L"} ${point.x} ${point.y}`
            )
            .join(" ");


    /*
     * =========================
     * AREA PATH
     * =========================
     */

    let areaPath = "";

    if (points.length > 0) {
        const first =
            points[0];

        const last =
            points[points.length - 1];

        areaPath = `
            ${linePath}
            L ${last.x} ${paddingTop + chartHeight}
            L ${first.x} ${paddingTop + chartHeight}
            Z
        `;
    }


    /*
     * =========================
     * GRID
     * =========================
     */

    let gridHTML = "";

    const gridCount = 4;

    for (
        let i = 0;
        i <= gridCount;
        i++
    ) {

        const y =
            paddingTop +
            (
                i /
                gridCount
            ) *
            chartHeight;

        const value =
            Math.round(
                maxValue -
                (
                    i /
                    gridCount
                ) *
                maxValue
            );

        gridHTML += `
            <line
                x1="${paddingLeft}"
                y1="${y}"
                x2="${width - paddingRight}"
                y2="${y}"
                class="chart-grid"
            ></line>

            <text
                x="${paddingLeft - 10}"
                y="${y + 4}"
                text-anchor="end"
                class="chart-axis-label"
            >
                ${formatNumber(value)}
            </text>
        `;
    }


    /*
     * =========================
     * DATE LABELS
     * =========================
     */

    let labelsHTML = "";

    points.forEach(point => {

        let label =
            point.date;

        if (point.date) {

            const date =
                new Date(
                    `${point.date}T00:00:00`
                );

            if (
                !Number.isNaN(
                    date.getTime()
                )
            ) {
                label =
                    date.toLocaleDateString(
                        "id-ID",
                        {
                            day: "2-digit",
                            month: "short"
                        }
                    );
            }
        }

        labelsHTML += `
            <text
                x="${point.x}"
                y="${height - 15}"
                text-anchor="middle"
                class="chart-date-label"
            >
                ${escapeHTML(label)}
            </text>
        `;
    });


    /*
     * =========================
     * POINTS
     * =========================
     */

    let pointsHTML = "";

    points.forEach(point => {

        pointsHTML += `
            <circle
                cx="${point.x}"
                cy="${point.y}"
                r="5"
                class="chart-point"
            >
                <title>
                    ${escapeHTML(
                        point.date
                    )}: ${formatNumber(
                        point.value
                    )} kunjungan
                </title>
            </circle>
        `;
    });


    /*
     * =========================
     * SVG
     * =========================
     */

    const wrapper =
        document.createElement("div");

    wrapper.className =
        "line-chart-wrapper";

    wrapper.innerHTML = `
        <svg
            class="line-chart"
            viewBox="0 0 ${width} ${height}"
            preserveAspectRatio="none"
            role="img"
            aria-label="Grafik kunjungan 7 hari terakhir"
        >

            ${gridHTML}

            ${
                areaPath
                    ? `
                        <path
                            d="${areaPath}"
                            class="chart-area"
                        ></path>
                    `
                    : ""
            }

            <path
                d="${linePath}"
                class="chart-line"
            ></path>

            ${pointsHTML}

            ${labelsHTML}

        </svg>
    `;

    elements.bars.appendChild(
        wrapper
    );
}


/* =========================
   LOAD DASHBOARD
========================= */

async function loadDashboard(
    showOverlay = true
) {
    if (showOverlay) {
        elements.loading.classList.remove(
            "hidden"
        );
    }

    try {

        await Promise.all([
            loadProducts(),
            loadStatistics()
        ]);

    } catch (error) {

        console.error(
            "Dashboard error:",
            error
        );

        if (
            error.message !==
            "Sesi admin sudah tidak valid."
        ) {
            alert(
                error.message ||
                "Gagal memuat dashboard."
            );
        }

    } finally {

        elements.loading.classList.add(
            "hidden"
        );
    }
}


/* =========================
   REFRESH
========================= */

elements.refresh?.addEventListener(
    "click",
    async () => {

        elements.refresh.classList.add(
            "loading"
        );

        try {

            await loadDashboard(false);

        } finally {

            elements.refresh.classList.remove(
                "loading"
            );
        }
    }
);


/* =========================
   LOGOUT
========================= */

document
    .getElementById("logoutButton")
    ?.addEventListener(
        "click",
        () => {

            const currentToken = sessionStorage.getItem(tokenKey);
            fetch("/api/admin/logout", { method:"POST", headers:{ Authorization:`Bearer ${currentToken}` } }).catch(()=>{}).finally(()=>{
                sessionStorage.removeItem(tokenKey);
                sessionStorage.removeItem(emailKey);
                sessionStorage.removeItem(roleKey);
                sessionStorage.removeItem("fydzstore_admin_username");
                window.location.href = "/admin/";
            });
        }
    );


/* =========================
   MOBILE SIDEBAR
========================= */

const sidebar =
    document.getElementById("sidebar");

document
    .getElementById("menuButton")
    ?.addEventListener(
        "click",
        () => {

            sidebar?.classList.toggle(
                "open"
            );
        }
    );


/* =========================
   NAVIGATION
========================= */

document
    .getElementById("productsNav")
    ?.addEventListener(
        "click",
        () => {

            window.location.href =
                "/admin/product/";
        }
    );

document.getElementById("addProductNav")?.addEventListener("click",()=>{ window.location.href="/admin/product/?add=1"; });
document.getElementById("ordersNav")?.addEventListener("click",()=>{ window.location.href="/admin/orders/"; });
document.getElementById("maintenanceNav")?.addEventListener("click",()=>{ if(adminRole==="developer") window.location.href="/admin/maintenance/"; });


document
    .getElementById("brandNav")
    ?.addEventListener(
        "click",
        () => {

            window.location.href =
                "/admin/brand/";
        }
    );


document
    .getElementById("statisticsNav")
    ?.addEventListener(
        "click",
        () => {

            window.location.href =
                "/admin/statistics/";
        }
    );


/* =========================
   START
========================= */

loadDashboard();


document.getElementById("reviewsNav")?.addEventListener("click", () => { window.location.href = "/admin/reviews/"; });
