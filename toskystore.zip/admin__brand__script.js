"use strict";

/* =========================================================
   CONFIG
========================================================= */

const API = {
    list: "/api/admin/brand/list",
    detail: "/api/admin/brand/detail",
    add: "/api/admin/brand/add",
    edit: "/api/admin/brand/edit",
    delete: "/api/admin/brand/dell",
};

const BRAND_LOGO_BASE = "/logo";
const tokenKey = "fydzstore_admin_token";
const emailKey = "fydzstore_admin_email";

/* =========================================================
   AUTH CHECK
========================================================= */

const token = sessionStorage.getItem(tokenKey);

if (!token) {
    window.location.href = "/admin/";
    throw new Error("Admin belum login.");
}

const adminEmailValue = sessionStorage.getItem(emailKey) || "-";

/* =========================================================
   STATE
========================================================= */

let brands = [];
let filteredBrands = [];
let currentMode = "create";
let currentBrand = null;
let selectedLogo = null;
let deleteTarget = null;
let toastTimer = null;

/* =========================================================
   DOM
========================================================= */

const sidebar = document.getElementById("sidebar");
const menuButton = document.getElementById("menuButton");
const brandsList = document.getElementById("brandsList");
const searchInput = document.getElementById("searchInput");
const refreshButton = document.getElementById("refreshButton");
const addBrandButton = document.getElementById("addBrandButton");

const brandModal = document.getElementById("brandModal");
const modalTitle = document.getElementById("modalTitle");
const modalClose = document.getElementById("modalClose");
const cancelButton = document.getElementById("cancelButton");
const saveButton = document.getElementById("saveButton");
const brandForm = document.getElementById("brandForm");

const brandId = document.getElementById("brandId");
const brandName = document.getElementById("brandName");
const brandDescription = document.getElementById("brandDescription");
const logoInput = document.getElementById("logoInput");
const logoPreview = document.getElementById("logoPreview");
const logoHint = document.getElementById("logoHint");

const confirmModal = document.getElementById("confirmModal");
const confirmBrandName = document.getElementById("confirmBrandName");
const confirmCancel = document.getElementById("confirmCancel");
const confirmDelete = document.getElementById("confirmDelete");

const toast = document.getElementById("toast");
const loadingOverlay = document.getElementById("loadingOverlay");
const loadingText = document.getElementById("loadingText");

const adminEmail = document.getElementById("adminEmail");
const adminAvatar = document.getElementById("adminAvatar");

const logoutButton = document.getElementById("logoutButton");

/* =========================================================
   API REQUEST (BEARER TOKEN)
========================================================= */

function authHeaders(withJsonType = true) {
    const headers = {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json"
    };

    if (withJsonType) {
        headers["Content-Type"] = "application/json";
    }

    return headers;
}

async function request(url, options = {}) {
    const isFormData = options.body instanceof FormData;

    const response = await fetch(url, {
        ...options,
        headers: {
            ...authHeaders(!isFormData),
            ...(options.headers || {})
        }
    });

    if (response.status === 401 || response.status === 403) {
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);
        window.location.href = "/admin/";
        throw new Error("Sesi admin sudah tidak valid.");
    }

    let data = null;
    try {
        data = await response.json();
    } catch {
        data = null;
    }

    if (!response.ok) {
        const message = data?.message || data?.error || `Request gagal (${response.status})`;
        const error = new Error(message);
        error.status = response.status;
        throw error;
    }

    return data;
}

function extractArray(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.data)) return data.data;
    if (Array.isArray(data?.brands)) return data.brands;
    return [];
}

/* =========================================================
   LOADING & TOAST
========================================================= */

function showLoading(text = "Memuat...") {
    loadingText.textContent = text;
    loadingOverlay.classList.remove("hidden");
}

function hideLoading() {
    loadingOverlay.classList.add("hidden");
}

function showToast(message, type = "") {
    clearTimeout(toastTimer);
    toast.textContent = message;
    toast.className = "toast";

    if (type) {
        toast.classList.add(type);
    }

    requestAnimationFrame(() => {
        toast.classList.add("show");
    });

    toastTimer = setTimeout(() => {
        toast.classList.remove("show");
    }, 3000);
}

/* =========================================================
   UTILITIES
========================================================= */

function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function formatDate(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return "-";

    return date.toLocaleDateString("id-ID", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    });
}

function getInitial(name) {
    const text = String(name || "B").trim();
    return text.charAt(0).toUpperCase() || "B";
}

function getLogoURL(brand) {
    if (!brand || !brand.logo) return null;
    
    const logo = String(brand.logo);
    
    if (logo.startsWith("http://") || logo.startsWith("https://")) return logo;
    if (logo.startsWith("/")) return logo;
    
    return `${BRAND_LOGO_BASE}/` + encodeURIComponent(logo);
}

/* =========================================================
   LOAD BRANDS
========================================================= */

async function loadBrands() {
    brandsList.innerHTML = `
        <div class="empty-state">
            Memuat brand...
        </div>
    `;

    try {
        const result = await request(API.list);
        
        brands = extractArray(result);
        applySearch();

    } catch (error) {
        console.error("[BRAND LIST ERROR]", error);

        brandsList.innerHTML = `
            <div class="empty-state">
                <div>
                    <div style="margin-bottom:8px; font-weight:700;">
                        Gagal memuat brand.
                    </div>
                    <div style="font-size:10px; color:#bbb;">
                        ${escapeHTML(error.message)}
                    </div>
                </div>
            </div>
        `;

        if (error.status !== 401) {
            showToast(error.message, "error");
        }
    }
}

/* =========================================================
   SEARCH & RENDER
========================================================= */

function applySearch() {
    const keyword = String(searchInput.value || "").trim().toLowerCase();

    if (!keyword) {
        filteredBrands = [...brands];
    } else {
        filteredBrands = brands.filter(brand => {
            const name = String(brand?.name || "").toLowerCase();
            const id = String(brand?.id || "").toLowerCase();
            const description = String(brand?.description || "").toLowerCase();

            return name.includes(keyword) || id.includes(keyword) || description.includes(keyword);
        });
    }
    renderBrands();
}

function renderBrands() {
    if (filteredBrands.length === 0) {
        const keyword = searchInput.value.trim();
        brandsList.innerHTML = `
            <div class="empty-state">
                ${keyword ? "Brand tidak ditemukan." : "Belum ada brand."}
            </div>
        `;
        return;
    }

    brandsList.innerHTML = filteredBrands.map(brand => createBrandRow(brand)).join("");

    // Setup Action Buttons
    brandsList.querySelectorAll("[data-edit-id]").forEach(button => {
        button.addEventListener("click", () => {
            openEditModal(button.dataset.editId);
        });
    });

    brandsList.querySelectorAll("[data-delete-id]").forEach(button => {
        button.addEventListener("click", () => {
            openDeleteConfirm(button.dataset.deleteId);
        });
    });
}

function createBrandRow(brand) {
    const logoURL = getLogoURL(brand);
    let logoHTML;

    if (logoURL) {
        logoHTML = `
            <img
                class="brand-logo"
                src="${escapeHTML(logoURL)}"
                alt="${escapeHTML(brand.name)}"
                loading="lazy"
                onerror="
                    this.style.display='none';
                    this.nextElementSibling.style.display='grid';
                "
            >
            <div class="brand-logo-empty" style="display:none;">
                ${escapeHTML(getInitial(brand.name))}
            </div>
        `;
    } else {
        logoHTML = `
            <div class="brand-logo-empty">
                ${escapeHTML(getInitial(brand.name))}
            </div>
        `;
    }

    const description = brand.description ? escapeHTML(brand.description) : "Tidak ada deskripsi.";

    return `
        <div class="brand-row">
            <div>
                ${logoHTML}
            </div>
            <div class="brand-info">
                <div class="brand-name">${escapeHTML(brand.name)}</div>
                <div class="brand-id">ID: ${escapeHTML(brand.id || "-")}</div>
            </div>
            <div class="brand-description">${description}</div>
            <div class="brand-date">${formatDate(brand.createdAt || brand.created_at)}</div>
            <div class="actions">
                <button
                    class="icon-button"
                    type="button"
                    title="Edit"
                    data-edit-id="${escapeHTML(brand.id)}"
                >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 20h9"></path>
                        <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"></path>
                    </svg>
                </button>
                <button
                    class="icon-button delete"
                    type="button"
                    title="Hapus"
                    data-delete-id="${escapeHTML(brand.id)}"
                >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 6h18"></path>
                        <path d="M8 6V4h8v2"></path>
                        <path d="M19 6l-1 15H6L5 6"></path>
                        <path d="M10 11v6M14 11v6"></path>
                    </svg>
                </button>
            </div>
        </div>
    `;
}

/* =========================================================
   MODAL ACTIONS (CREATE & EDIT)
========================================================= */

function openCreateModal() {
    currentMode = "create";
    currentBrand = null;
    selectedLogo = null;

    brandForm.reset();
    brandId.value = "";
    modalTitle.textContent = "Tambah Brand";
    saveButton.textContent = "Simpan Brand";
    logoHint.textContent = "Logo bersifat opsional.";
    
    resetLogoPreview();
    brandModal.classList.add("show");

    setTimeout(() => { brandName.focus(); }, 100);
}

async function openEditModal(id) {
    currentMode = "edit";
    selectedLogo = null;
    showLoading("Memuat detail brand...");

    try {
        // Find dari local array (lebih cepat jika list sudah komplit). 
        // Jika perlu bisa request fetch detail seperti sedia kala.
        let brand = brands.find(b => String(b.id) === String(id));
        
        if (!brand) {
            // Coba fetch detail sebagai fallback
            const result = await request(`${API.detail}?id=${encodeURIComponent(id)}`);
            brand = result?.data;
            if (!brand) throw new Error("Data brand tidak ditemukan.");
        }

        currentBrand = brand;
        brandId.value = brand.id || "";
        brandName.value = brand.name || brand.nama || "";
        brandDescription.value = brand.description || "";

        modalTitle.textContent = "Edit Brand";
        saveButton.textContent = "Simpan Perubahan";
        logoHint.textContent = brand.logo
            ? "Pilih logo baru jika ingin mengganti logo."
            : "Brand belum memiliki logo.";

        setExistingLogoPreview(brand);
        brandModal.classList.add("show");

        setTimeout(() => { brandName.focus(); }, 100);

    } catch (error) {
        console.error("[BRAND DETAIL ERROR]", error);
        showToast(error.message, "error");
    } finally {
        hideLoading();
    }
}

function closeBrandModal() {
    brandModal.classList.remove("show");
    currentBrand = null;
    selectedLogo = null;
}

/* =========================================================
   LOGO UPLOAD PREVIEW
========================================================= */

function resetLogoPreview() {
    logoPreview.innerHTML = "◎";
}

function setExistingLogoPreview(brand) {
    const url = getLogoURL(brand);
    if (!url) {
        resetLogoPreview();
        return;
    }

    logoPreview.innerHTML = `
        <img
            src="${escapeHTML(url)}"
            alt="${escapeHTML(brand.name)}"
            onerror="this.parentElement.innerHTML='◎';"
        >
    `;
}

logoInput.addEventListener("change", () => {
    const file = logoInput.files?.[0];

    if (!file) {
        selectedLogo = null;
        if (currentMode === "edit" && currentBrand) {
            setExistingLogoPreview(currentBrand);
        } else {
            resetLogoPreview();
        }
        return;
    }

    if (!file.type.startsWith("image/")) {
        logoInput.value = "";
        selectedLogo = null;
        showToast("File logo harus berupa gambar.", "error");
        return;
    }

    if (file.size > 5 * 1024 * 1024) {
        logoInput.value = "";
        selectedLogo = null;
        showToast("Ukuran logo maksimal 5 MB.", "error");
        return;
    }

    selectedLogo = file;
    const reader = new FileReader();

    reader.onload = event => {
        logoPreview.innerHTML = `
            <img src="${event.target.result}" alt="Preview logo">
        `;
    };

    reader.readAsDataURL(file);
    logoHint.textContent = file.name;
});

/* =========================================================
   SAVE DATA
========================================================= */

function validateForm() {
    const name = brandName.value.trim();
    if (!name) {
        showToast("Nama brand wajib diisi.", "error");
        brandName.focus();
        return false;
    }
    return true;
}

async function saveBrand() {
    if (!validateForm()) return;

    const formData = new FormData();
    formData.append("name", brandName.value.trim());
    formData.append("description", brandDescription.value.trim());

    if (selectedLogo) {
        formData.append("logo", selectedLogo);
    }

    if (currentMode === "edit") {
        formData.append("id", brandId.value);
    }

    const endpoint = currentMode === "create" ? API.add : API.edit;
    saveButton.disabled = true;
    showLoading(currentMode === "create" ? "Membuat brand..." : "Menyimpan perubahan...");

    try {
        const result = await request(endpoint, {
            method: "POST",
            body: formData,
        });

        const savedMode = currentMode;
        closeBrandModal();

        showToast(
            result?.message || (savedMode === "create" ? "Brand berhasil dibuat." : "Brand berhasil diperbarui."),
            "success"
        );

        await loadBrands();

    } catch (error) {
        console.error("[BRAND SAVE ERROR]", error);
        showToast(error.message, "error");
    } finally {
        saveButton.disabled = false;
        hideLoading();
    }
}

/* =========================================================
   DELETE DATA
========================================================= */

function openDeleteConfirm(id) {
    const brand = brands.find(item => String(item.id) === String(id));
    if (!brand) {
        showToast("Brand tidak ditemukan.", "error");
        return;
    }

    deleteTarget = brand;
    confirmBrandName.textContent = brand.name || brand.nama;
    confirmModal.classList.add("show");
}

function closeDeleteConfirm() {
    confirmModal.classList.remove("show");
    deleteTarget = null;
}

async function deleteBrand() {
    if (!deleteTarget) return;
    const id = deleteTarget.id;

    confirmDelete.disabled = true;
    showLoading("Menghapus brand...");

    try {
        const result = await request(API.delete, {
            method: "POST",
            body: JSON.stringify({ id }),
        });

        closeDeleteConfirm();
        showToast(result?.message || "Brand berhasil dihapus.", "success");
        await loadBrands();

    } catch (error) {
        console.error("[BRAND DELETE ERROR]", error);
        showToast(error.message, "error");
    } finally {
        confirmDelete.disabled = false;
        hideLoading();
    }
}

/* =========================================================
   NAVIGATION & SIDEBAR
========================================================= */

function goTo(path) {
    window.location.href = path;
}

document.getElementById("dashboardNav")?.addEventListener("click", () => {
    goTo("/admin/dashboard/");
});

document.getElementById("productNav")?.addEventListener("click", () => {
    goTo("/admin/product/");
});

document.getElementById("brandNav")?.addEventListener("click", () => {
    goTo("/admin/brand/");
});

document.getElementById("statisticsNav")?.addEventListener("click", () => {
    goTo("/admin/statistics/");
});

function openSidebar() {
    sidebar?.classList.add("open");
}

function closeSidebar() {
    sidebar?.classList.remove("open");
}

menuButton?.addEventListener("click", () => {
    sidebar.classList.toggle("open");
});

/* =========================================================
   LOGOUT
========================================================= */

function logout() {
    const currentToken = sessionStorage.getItem(tokenKey);
    fetch("/api/admin/logout", {method:"POST", headers:{Authorization:`Bearer ${currentToken}`}}).catch(()=>{}).finally(()=>{
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);
        sessionStorage.removeItem("fydzstore_admin_role");
        sessionStorage.removeItem("fydzstore_admin_username");
        window.location.href = "/admin/";
    });
}

logoutButton?.addEventListener("click", () => {
    logout();
});

/* =========================================================
   EVENTS BINDING
========================================================= */

addBrandButton?.addEventListener("click", openCreateModal);

refreshButton?.addEventListener("click", async () => {
    refreshButton.disabled = true;
    await loadBrands();
    refreshButton.disabled = false;
});

searchInput?.addEventListener("input", applySearch);
modalClose?.addEventListener("click", closeBrandModal);
cancelButton?.addEventListener("click", closeBrandModal);
saveButton?.addEventListener("click", saveBrand);
confirmCancel?.addEventListener("click", closeDeleteConfirm);
confirmDelete?.addEventListener("click", deleteBrand);
brandForm?.addEventListener("submit", event => {
    event.preventDefault();
    saveBrand();
});

brandModal?.addEventListener("click", event => {
    if (event.target === brandModal) closeBrandModal();
});

confirmModal?.addEventListener("click", event => {
    if (event.target === confirmModal) closeDeleteConfirm();
});

document.addEventListener("keydown", event => {
    if (event.key !== "Escape") return;

    if (brandModal?.classList.contains("show")) {
        closeBrandModal();
        return;
    }
    if (confirmModal?.classList.contains("show")) {
        closeDeleteConfirm();
    }
});

/* =========================================================
   INIT
========================================================= */

async function init() {
    // Setel info admin di sidebar dari data session.
    adminEmail.textContent = adminEmailValue;
    adminAvatar.textContent = adminEmailValue.charAt(0).toUpperCase();

    await loadBrands();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
} else {
    init();
}