const LOGIN_ENDPOINT = "/api/admin/login";

const loginForm = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const passwordToggle = document.getElementById("passwordToggle");

const loginButton = document.getElementById("loginButton");
const errorBox = document.getElementById("errorBox");
const successBox = document.getElementById("successBox");


function showError(message) {
    errorBox.textContent = message;
    errorBox.style.display = "block";

    successBox.textContent = "";
    successBox.style.display = "none";
}


function showSuccess(message) {
    successBox.textContent = message;
    successBox.style.display = "block";

    errorBox.textContent = "";
    errorBox.style.display = "none";
}


function hideMessages() {
    errorBox.style.display = "none";
    successBox.style.display = "none";

    errorBox.textContent = "";
    successBox.textContent = "";
}


function setLoading(loading) {
    loginButton.disabled = loading;

    if (loading) {
        loginButton.classList.add("loading");
        loginButton.querySelector(".button-text").textContent =
            "Memproses...";
    } else {
        loginButton.classList.remove("loading");
        loginButton.querySelector(".button-text").textContent =
            "Masuk ke Dashboard";
    }
}


function getToken(data) {
    return (
        data?.token ||
        data?.accessToken ||
        data?.data?.token ||
        data?.data?.accessToken ||
        null
    );
}


passwordToggle.addEventListener("click", () => {
    const isPassword =
        passwordInput.type === "password";

    passwordInput.type =
        isPassword ? "text" : "password";

    passwordToggle.textContent =
        isPassword ? "Sembunyikan" : "Lihat";
});


loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    hideMessages();

    const email = emailInput.value.trim();
    const password = passwordInput.value;

    if (!email || !password) {
        showError("Username/email dan password wajib diisi.");
        return;
    }

    setLoading(true);

    try {
        const response = await fetch(LOGIN_ENDPOINT, {
            method: "POST",
            credentials: "include",
            cache: "no-store",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                email,
                username: email,
                password
            })
        });

        let data = null;

        try {
            data = await response.json();
        } catch {
            data = null;
        }

        if (!response.ok) {
            throw new Error(
                data?.message ||
                data?.error ||
                "Username/email atau password salah."
            );
        }

        const token = getToken(data);

        if (!token) {
            throw new Error(
                "Login berhasil tetapi token admin tidak ditemukan dari server."
            );
        }

        /*
         * Token disimpan di sessionStorage supaya hanya
         * aktif selama tab/browser session ini masih berjalan.
         */
        sessionStorage.setItem("fydzstore_admin_token", token);
        localStorage.setItem("fydzstore_admin_token", token);

        sessionStorage.setItem("fydzstore_admin_email", data?.admin?.email || email);
        sessionStorage.setItem("fydzstore_admin_username", data?.admin?.username || email);
        sessionStorage.setItem("fydzstore_admin_role", data?.admin?.role || "admin");
        localStorage.setItem("fydzstore_admin_email", data?.admin?.email || email);
        localStorage.setItem("fydzstore_admin_username", data?.admin?.username || email);
        localStorage.setItem("fydzstore_admin_role", data?.admin?.role || "admin");

        showSuccess("Login berhasil. Membuka dashboard...");

        setTimeout(() => {
            window.location.href = "/admin/dashboard/";
        }, 500);

    } catch (error) {
        console.error("Admin login error:", error);

        showError(
            error.message ||
            "Terjadi kesalahan saat login."
        );

    } finally {
        setLoading(false);
    }
});


/*
 * Kalau admin sudah punya token,
 * langsung arahkan ke dashboard.
 */
(function checkExistingSession() {
    const token = sessionStorage.getItem("fydzstore_admin_token") || localStorage.getItem("fydzstore_admin_token");
    if (token) { sessionStorage.setItem("fydzstore_admin_token", token); window.location.replace("/admin/dashboard/"); }
})();
