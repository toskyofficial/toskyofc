(() => {
    const START_TIME = Date.now();

    /* =========================
       VISITOR ID
    ========================= */

    function getVisitorId() {
        let visitorId =
            localStorage.getItem(
                "fydzstore_visitor_id"
            );

        if (!visitorId) {
            visitorId =
                crypto.randomUUID
                    ? crypto.randomUUID()
                    : `${Date.now()}-${Math.random()
                        .toString(36)
                        .slice(2)}`;

            localStorage.setItem(
                "fydzstore_visitor_id",
                visitorId
            );
        }

        return visitorId;
    }


    /* =========================
       PRODUCT DATA
    ========================= */

    function getProductData() {

        /*
         * Opsi 1:
         * data-product-id
         * data-product-name
         *
         * Contoh:
         *
         * <body
         *   data-product-id="534479544b524282"
         *   data-product-name="Kaos Sablon"
         * >
         */

        const body =
            document.body;

        const productId =
            body?.dataset?.productId ||
            document.documentElement.dataset.productId;

        const productName =
            body?.dataset?.productName ||
            document.documentElement.dataset.productName;


        if (!productId) {
            return null;
        }


        return {
            productId:
                String(productId),

            productName:
                productName
                    ? String(productName)
                    : undefined
        };
    }


    /* =========================
       TRACK STATISTICS
    ========================= */

    function trackStatistics() {

        const duration =
            Math.max(
                0,
                Math.floor(
                    (Date.now() -
                        START_TIME) /
                    1000
                )
            );


        const product =
            getProductData();


        const data = {
            visitorId:
                getVisitorId(),

            page:
                window.location.pathname,

            duration
        };


        /*
         * Kalau halaman adalah
         * halaman produk, tambahkan
         * informasi produk.
         */

        if (product) {

            data.productId =
                product.productId;

            if (product.productName) {
                data.productName =
                    product.productName;
            }
        }


        console.log(
            "[STATISTICS]",
            data
        );


        fetch(
            "/api/statistics/track",
            {
                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body:
                    JSON.stringify(data),

                keepalive: true
            }
        )
            .then(
                async response => {

                    let result = null;

                    try {
                        result =
                            await response.json();
                    } catch {
                        result = null;
                    }


                    console.log(
                        "[STATISTICS RESPONSE]",
                        response.status,
                        result
                    );
                }
            )
            .catch(
                error => {

                    console.error(
                        "[STATISTICS ERROR]",
                        error
                    );
                }
            );
    }


    /* =========================
       PAGE HIDDEN
    ========================= */

    window.addEventListener(
        "pagehide",
        trackStatistics
    );

})();