"use strict";
let fydzUser=null;
const CUSTOMER_TOKEN_KEY="fydz_customer_token";
function getCustomerToken(){return localStorage.getItem(CUSTOMER_TOKEN_KEY)||sessionStorage.getItem(CUSTOMER_TOKEN_KEY)||"";}
function extractToken(d){return d?.token||d?.accessToken||d?.data?.token||d?.data?.accessToken||"";}
function customerAuthHeaders(extra={}){const t=getCustomerToken();return t?{...extra,Authorization:`Bearer ${t}`}:{...extra};}
const loginModal=document.getElementById("loginModal");
const registerModal=document.getElementById("registerModal");
const accountModal=document.getElementById("accountModal");
const loginTrigger=document.getElementById("accountLoginTrigger");
const registerTrigger=document.getElementById("accountRegisterTrigger");
const loginForm=document.getElementById("authLoginForm");
const registerForm=document.getElementById("authRegisterForm");
const loginError=document.getElementById("authLoginError");
const registerError=document.getElementById("authRegisterError");
function showModal(el){if(!el)return;el.hidden=false;el.setAttribute("aria-hidden","false");}
function hideModal(el){if(!el)return;el.hidden=true;el.setAttribute("aria-hidden","true");}
function openLogin(){
  if(!loginModal){ window.location.href="/?login=1"; return; }
  hideModal(registerModal);hideModal(accountModal);showModal(loginModal);
}
function openRegister(){
  if(!registerModal){ window.location.href="/?register=1"; return; }
  hideModal(loginModal);hideModal(accountModal);showModal(registerModal);
}
function closeAll(){hideModal(loginModal);hideModal(registerModal);hideModal(accountModal);}
function err(el,msg){if(el){el.textContent=msg||"Terjadi kesalahan.";el.hidden=false;}}
function clearErr(el){if(el){el.textContent="";el.hidden=true;}}
function renderAccount(){
  const logged=Boolean(fydzUser);
  if(loginTrigger) loginTrigger.textContent=logged?"👤 Akun":"👤 Masuk";
  if(registerTrigger) registerTrigger.hidden=logged;
  if(accountModal && logged){
    const name=document.getElementById("accountName"), email=document.getElementById("accountEmail"), avatar=document.getElementById("accountAvatar");
    if(name) name.textContent=fydzUser.name||fydzUser.username||"Customer";
    if(email) email.textContent=fydzUser.email||("@"+(fydzUser.username||"user"));
    if(avatar){avatar.src=fydzUser.avatar||"/assets__fydz-logo.svg";avatar.onerror=()=>avatar.src="/assets__fydz-logo.svg";}
  }
}
async function loadAuth(){try{const token=getCustomerToken();const r=await fetch("/api/auth/me",{cache:"no-store",credentials:"include",headers:token?{Authorization:`Bearer ${token}`}:{} });const d=await r.json();fydzUser=d.user||null;renderAccount();window.dispatchEvent(new CustomEvent("fydz-auth-ready",{detail:{user:fydzUser}}));}catch(e){console.warn("Auth check failed",e);}}
async function submitAuth(form,mode,errorEl){clearErr(errorEl);const fd=new FormData(form);const username=String(fd.get("username")||"").trim();const password=String(fd.get("password")||"");if(mode==="register"&&password!==String(fd.get("passwordConfirm")||""))return err(errorEl,"Konfirmasi password tidak sama.");const btn=form.querySelector("button[type=submit]");if(btn)btn.disabled=true;try{const r=await fetch(`/api/auth/${mode}`,{method:"POST",headers:{"Content-Type":"application/json"},credentials:"include",body:JSON.stringify({username,password})});const d=await r.json();if(!r.ok)throw new Error(d.error||"Autentikasi gagal.");const token=extractToken(d);if(token){localStorage.setItem(CUSTOMER_TOKEN_KEY,token);sessionStorage.setItem(CUSTOMER_TOKEN_KEY,token);}fydzUser=d.user||null;if(!fydzUser){await loadAuth();}if(!fydzUser)throw new Error("Login berhasil, tetapi sesi akun belum terbaca. Coba lagi setelah backend diperbarui.");renderAccount();window.dispatchEvent(new CustomEvent("fydz-auth-ready",{detail:{user:fydzUser}}));form.reset();closeAll();if(window.showToast)window.showToast(mode==="login"?"Berhasil login!":"Akun berhasil dibuat!");}catch(e){err(errorEl,e.message)}finally{if(btn)btn.disabled=false;}}
loginTrigger?.addEventListener("click",()=>fydzUser?(showModal(accountModal)):openLogin());
registerTrigger?.addEventListener("click",openRegister);
document.getElementById("loginClose")?.addEventListener("click",closeAll);
document.getElementById("registerClose")?.addEventListener("click",closeAll);
document.getElementById("accountClose")?.addEventListener("click",closeAll);
document.querySelectorAll("[data-close-login],[data-close-register],[data-close-account]").forEach(x=>x.addEventListener("click",closeAll));
document.getElementById("switchToRegister")?.addEventListener("click",openRegister);
document.getElementById("switchToLogin")?.addEventListener("click",openLogin);
loginForm?.addEventListener("submit",e=>{e.preventDefault();submitAuth(loginForm,"login",loginError)});
registerForm?.addEventListener("submit",e=>{e.preventDefault();submitAuth(registerForm,"register",registerError)});
document.getElementById("accountLogout")?.addEventListener("click",async()=>{await fetch("/api/auth/logout",{method:"POST",credentials:"include"});fydzUser=null;renderAccount();closeAll();window.location.reload();});
window.FydzAuth={getUser:()=>fydzUser,refresh:loadAuth,open:openLogin,openLogin,openRegister};
document.addEventListener("DOMContentLoaded",()=>{loadAuth();const params=new URLSearchParams(location.search);if(params.get("login")==="1"){history.replaceState({},"",location.pathname+location.hash);setTimeout(openLogin,250)}if(params.get("register")==="1"){history.replaceState({},"",location.pathname+location.hash);setTimeout(openRegister,250)}});
