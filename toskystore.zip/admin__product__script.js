"use strict";


/* =========================================================
   API
========================================================= */

const API = {

    list: "/api/admin/product/list",

    add: "/api/admin/product/add",

    edit: "/api/admin/product/edit",

    dell: "/api/admin/product/dell",

    brandList: "/api/admin/brand/list"

};


const tokenKey =
    "fydzstore_admin_token";

const emailKey =
    "fydzstore_admin_email";


/* =========================================================
   AUTH
========================================================= */

const token =
    sessionStorage.getItem(
        tokenKey
    );


if (!token) {

    window.location.href =
        "/admin/";

    throw new Error(
        "Admin belum login."
    );
}


const adminEmail =
    sessionStorage.getItem(
        emailKey
    ) || "-";


/* =========================================================
   STATE
========================================================= */

let products = [];

let brands = [];


/* =========================================================
   DOM
========================================================= */

const elements = {

    sidebar:
        document.getElementById(
            "sidebar"
        ),

    menuButton:
        document.getElementById(
            "menuButton"
        ),

    adminEmail:
        document.getElementById(
            "adminEmail"
        ),

    adminAvatar:
        document.getElementById(
            "adminAvatar"
        ),

    productsList:
        document.getElementById(
            "productsList"
        ),

    totalProducts:
        document.getElementById(
            "totalProducts"
        ),

    hostingProducts:
        document.getElementById(
            "hostingProducts"
        ),

    totalCategories:
        document.getElementById(
            "totalCategories"
        ),

    searchInput:
        document.getElementById(
            "searchInput"
        ),

    refreshButton:
        document.getElementById(
            "refreshButton"
        ),

    saveButton:
        document.getElementById(
            "saveButton"
        ),

    toast:
        document.getElementById(
            "toast"
        ),

    loading:
        document.getElementById(
            "loadingOverlay"
        ),

    logoutButton:
        document.getElementById(
            "logoutButton"
        ),

    dashboardNav:
        document.getElementById(
            "dashboardNav"
        ),

    brandNav:
        document.getElementById(
            "brandNav"
        ),

    statisticsNav:
        document.getElementById(
            "statisticsNav"
        )

};


/* =========================================================
   INIT
========================================================= */

elements.adminEmail.textContent =
    adminEmail;


elements.adminAvatar.textContent =
    adminEmail
        .charAt(0)
        .toUpperCase();


setupEvents();

loadProducts();
if (new URLSearchParams(window.location.search).get("add") === "1") { setTimeout(() => window.openProductModal?.(), 250); }


/* =========================================================
   AUTH HEADERS
========================================================= */

function authHeaders(
    withJsonType = true
) {

    const headers = {

        "Authorization":
            `Bearer ${token}`,

        "Accept":
            "application/json"

    };


    if (withJsonType) {

        headers["Content-Type"] =
            "application/json";

    }


    return headers;

}


/* =========================================================
   REQUEST
========================================================= */

async function request(
    url,
    options = {}
) {

    const isFormData =
        options.body instanceof
        FormData;


    const response =
        await fetch(
            url,
            {
                ...options,

                headers: {
                    ...authHeaders(
                        !isFormData
                    ),
                    ...(options.headers || {})
                }
            }
        );


    if (
        response.status === 401 ||
        response.status === 403
    ) {

        sessionStorage.removeItem(
            tokenKey
        );

        sessionStorage.removeItem(
            emailKey
        );

        window.location.href =
            "/admin/";

        throw new Error(
            "Sesi admin sudah tidak valid."
        );
    }


    let data = null;


    try {

        data =
            await response.json();

    } catch {

        data = null;

    }


    if (!response.ok) {

        throw new Error(

            data?.message ||

            data?.error ||

            `Request gagal (${response.status})`

        );

    }


    return data;

}


/* =========================================================
   ARRAY EXTRACTOR
========================================================= */

function extractArray(data) {

    if (
        Array.isArray(data)
    ) {

        return data;

    }


    if (
        Array.isArray(data?.data)
    ) {

        return data.data;

    }


    if (
        Array.isArray(data?.products)
    ) {

        return data.products;

    }


    if (
        Array.isArray(data?.brands)
    ) {

        return data.brands;

    }


    if (
        Array.isArray(
            data?.data?.products
        )
    ) {

        return data.data.products;

    }


    return [];

}


/* =========================================================
   BRANDS
========================================================= */

async function loadBrands(
    selectedId = ""
) {

    const select =
        document.getElementById(
            "productBrand"
        );


    if (!select) {
        return;
    }


    select.innerHTML =
        `<option value="">Memuat brand...</option>`;


    try {

        const response =
            await request(
                API.brandList
            );


        brands =
            extractArray(
                response
            );


        if (!brands.length) {

            select.innerHTML =
                `<option value="">Belum ada brand, tambahkan dulu</option>`;

            return;

        }


        select.innerHTML =

            `<option value="">Pilih brand</option>` +

            brands
                .map(
                    brand => {

                        const id =
                            brand?.id ??
                            brand?._id ??
                            "";

                        const name =
                            brand?.name ??
                            brand?.nama ??
                            "Brand tanpa nama";

                        return `
                            <option value="${escapeAttribute(id)}">
                                ${escapeHTML(name)}
                            </option>
                        `;

                    }
                )
                .join("");


        if (selectedId) {

            select.value =
                String(
                    selectedId
                );

        }


    } catch (error) {

        console.error(
            "Load brands error:",
            error
        );


        select.innerHTML =
            `<option value="">Gagal memuat brand</option>`;


        notify(
            error.message ||
            "Gagal memuat daftar brand.",
            true
        );

    }

}


// Dipanggil langsung dari inline script di products.html
window.loadBrands = loadBrands;


/* =========================================================
   LOAD PRODUCTS
========================================================= */

async function loadProducts() {

    setLoading(true);


    try {

        const response =
            await request(
                API.list
            );


        products =
            extractArray(
                response
            );


        renderStats();

        renderProducts(
            products
        );


    } catch (error) {

        console.error(
            "Load products error:",
            error
        );


        elements.productsList.innerHTML = `

            <div class="empty-state">

                Gagal memuat produk.<br>

                ${escapeHTML(
                    error.message ||
                    "Unknown error"
                )}

            </div>

        `;


        if (
            error.message !==
            "Sesi admin sudah tidak valid."
        ) {

            notify(
                error.message ||
                "Gagal memuat produk.",
                true
            );

        }

    } finally {

        setLoading(false);

    }

}


/* =========================================================
   STATS
========================================================= */

function renderStats() {

    const categories =
        new Set();


    products.forEach(
        product => {

            categories.add(
                getCategory(
                    product
                )
            );

        }
    );


    const hosting =
        products.filter(
            product =>
                getCategory(
                    product
                ) === "hosting"
        ).length;


    elements.totalProducts.textContent =
        formatNumber(
            products.length
        );


    elements.hostingProducts.textContent =
        formatNumber(
            hosting
        );


    elements.totalCategories.textContent =
        formatNumber(
            categories.size
        );

}


/* =========================================================
   RENDER PRODUCTS
========================================================= */

function renderProducts(
    data
) {

    const keyword =
        String(
            elements.searchInput.value ||
            ""
        )
            .trim()
            .toLowerCase();


    const filtered =
        data.filter(
            product => {

                if (!keyword) {
                    return true;
                }


                return (

                    String(
                        product?.name ||
                        ""
                    )
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                    ||

                    String(
                        product?.category ||
                        ""
                    )
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                    ||

                    String(
                        product?.id ||
                        ""
                    )
                        .toLowerCase()
                        .includes(
                            keyword
                        )

                );

            }
        );


    if (!filtered.length) {

        elements.productsList.innerHTML = `

            <div class="empty-state">

                ${
                    keyword
                        ? "Produk tidak ditemukan."
                        : "Belum ada produk."
                }

            </div>

        `;

        return;

    }


    elements.productsList.innerHTML =
        filtered
            .map(
                product =>
                    renderProductRow(
                        product
                    )
            )
            .join("");

}


/* =========================================================
   PRODUCT ROW
========================================================= */

function renderProductRow(
    product
) {

    const image =
        normalizeMediaUrl(
            product?.thumbnailProduct ??
            product?.thumbnail
        );


    const name =
        product?.name ||
        "Tanpa nama";


    const category =
        getCategory(
            product
        );


    const price =
        formatPrice(
            product?.price
        );


    return `

        <div
            class="product-row"
            data-id="${escapeAttribute(
                product?.id || ""
            )}"
        >

            <img
                class="product-image"
                src="${escapeAttribute(
                    image
                )}"
                alt="${escapeAttribute(
                    name
                )}"
                onerror="
                    this.src='/assets__fydz-logo.svg'
                "
            >


            <div class="product-info">

                <div class="product-name">

                    ${escapeHTML(
                        name
                    )}

                </div>

                <div class="product-id">

                    ID:
                    ${escapeHTML(
                        product?.id ||
                        "-"
                    )}

                </div>

            </div>


            <div class="category-badge">

                ${escapeHTML(
                    category
                )}

            </div>


            <div class="product-price">

                ${escapeHTML(
                    price
                )}

            </div>


            <div class="actions">

                <button
                    class="icon-button"
                    title="Edit"
                    data-action="edit"
                    data-id="${escapeAttribute(
                        product?.id || ""
                    )}"
                >

                    ✏️ Edit

                </button>


                <button
                    class="icon-button delete"
                    title="Hapus"
                    data-action="delete"
                    data-id="${escapeAttribute(
                        product?.id || ""
                    )}"
                >

                    🗑 Hapus

                </button>

            </div>

        </div>

    `;

}


/* =========================================================
   OPEN EDIT (pakai modal dari products.html)
========================================================= */

function openEdit(
    product
) {

    if (!product) {
        return;
    }


    window.openProductModal({

        mode: "edit",

        product: {

            id:
                product?.id,

            name:
                product?.name,

            price:
                product?.price,

            category:
                product?.category,

            description:
                product?.description,

            brandId:
                product?.brandID ??
                product?.brandId ??
                product?.brand_id ??
                product?.brand?.id ??
                "",

            whatsapp:
                product?.contact?.whatsapp,

            instagram:
                product?.contact?.instagram,

            facebook:
                product?.contact?.facebook,

            tiktok:
                product?.contact?.tiktok,

            shopee:
                product?.contact?.shopee,

            thumbnail:
                product?.thumbnailProduct ??
                product?.thumbnail ??
                null,

            images:
                product?.imagesProduct ??
                product?.images ??
                []

        }

    });

}


/* =========================================================
   DELETE
========================================================= */

async function deleteProduct(
    product
) {

    if (!product) {
        return;
    }


    const name =
        product.name ||
        "produk ini";


    const confirmed =
        window.confirm(
            `Hapus "${name}"?\n\nTindakan ini tidak dapat dibatalkan.`
        );


    if (!confirmed) {
        return;
    }


    setLoading(true);


    try {

        const response =
            await request(
                API.dell,
                {
                    method:
                        "POST",

                    body:
                        JSON.stringify({
                            id:
                                product.id
                        })
                }
            );


        console.log(
            "[PRODUCT DELETE]",
            response
        );


        notify(
            "Produk berhasil dihapus."
        );


        await loadProducts();


    } catch (error) {

        console.error(
            "Delete product error:",
            error
        );


        notify(
            error.message ||
            "Gagal menghapus produk.",
            true
        );

    } finally {

        setLoading(false);

    }

}


/* =========================================================
   IMAGE VALUE RESOLVER
========================================================
   window.productImageState menyimpan item berbentuk:

   - { existing: true, url, preview }   -> gambar lama (belum diganti),
                                            di-fetch balik jadi Blob kalau
                                            perlu dikirim ulang sebagai file.
   - { blob, name, preview }            -> hasil crop baru, siap dikirim
                                            langsung sebagai file.

   Backend (multer) hanya menerima file asli lewat
   multipart/form-data, jadi semuanya di sini harus
   berakhir sebagai Blob, bukan base64/JSON.
======================================================== */

async function resolveImageBlob(
    item
) {

    if (!item) {
        return null;
    }


    if (item.blob) {

        return {
            blob: item.blob,
            name:
                item.name ||
                "image.jpg"
        };

    }


    if (
        item.existing &&
        item.url
    ) {

        try {

            const response =
                await fetch(
                    item.url
                );

            const blob =
                await response.blob();

            const name =
                item.url
                    .split("/")
                    .pop() ||
                "image.jpg";

            return {
                blob,
                name
            };

        } catch (error) {

            console.error(
                "Gagal mengambil ulang gambar lama:",
                item.url,
                error
            );

            return null;

        }

    }


    return null;

}


/* =========================================================
   SAVE (ADD / EDIT)
========================================================
   Endpoint asli backend:

   POST /api/admin/product/add   (multipart/form-data)
   POST /api/admin/product/edit  (multipart/form-data, field "id")

   Bukan JSON base64 -> menghindari 413 Payload Too Large
   yang muncul waktu payload JSON kelebihan limit body-parser.
======================================================== */

window.handleProductSave =
    async function () {

        if (
            !window.validateProductForm()
        ) {

            return;

        }


        const data =
            window.getProductFormData();


        const editing =
            Boolean(
                data.id
            );


        // Thumbnail wajib ada untuk produk baru
        if (
            !editing &&
            !data.thumbnail
        ) {

            notify(
                "Thumbnail produk wajib diupload.",
                true
            );

            return;

        }


        elements.saveButton.disabled =
            true;

        elements.saveButton.textContent =
            editing
                ? "Menyimpan..."
                : "Menambahkan...";


        try {

            const formData =
                new FormData();


            if (editing) {

                formData.append(
                    "id",
                    data.id
                );

            }


            formData.append(
                "name",
                data.name
            );

            formData.append(
                "description",
                data.description
            );

            formData.append(
                "price",
                String(
                    data.price
                )
            );

            // Brand bersifat opsional. Jangan kirim field kosong
            // agar saat edit foto saja, brand lama tetap dipertahankan.
            if (data.brandId) {
                formData.append(
                    "brandID",
                    data.brandId
                );
            }

            formData.append(
                "category",
                data.category
            );

            formData.append(
                "whatsapp",
                data.whatsapp
            );

            formData.append(
                "instagram",
                data.instagram ||
                ""
            );

            formData.append(
                "facebook",
                data.facebook ||
                ""
            );

            formData.append(
                "tiktok",
                data.tiktok ||
                ""
            );

            formData.append(
                "shopee",
                data.shopee ||
                ""
            );


            /*
             * THUMBNAIL
             *
             * Hanya dikirim kalau ada crop baru.
             * Kalau tidak diganti saat edit,
             * biarkan field ini kosong supaya
             * backend mempertahankan thumbnail lama.
             */

            if (
                data.thumbnail?.blob
            ) {

                formData.append(
                    "thumbnail",
                    data.thumbnail.blob,
                    data.thumbnail.name ||
                    "thumbnail.jpg"
                );

            }


            /*
             * IMAGES
             *
             * Backend me-replace SELURUH galeri kalau
             * ada file images yang dikirim. Supaya
             * hapus/tambah gambar di form tercermin
             * dengan benar, kirim ulang SEMUA gambar
             * yang masih ada di preview (existing
             * di-fetch balik jadi Blob, yang baru
             * dipakai langsung).
             */

            const resolvedImages = [];

            for (
                const item of
                data.images
            ) {

                const resolved =
                    await resolveImageBlob(
                        item
                    );

                if (resolved) {

                    resolvedImages.push(
                        resolved
                    );

                }

            }


            resolvedImages.forEach(
                image => {

                    formData.append(
                        "images",
                        image.blob,
                        image.name
                    );

                }
            );


            const url =
                editing
                    ? API.edit
                    : API.add;


            const response =
                await request(
                    url,
                    {
                        method:
                            "POST",

                        body:
                            formData
                    }
                );


            console.log(
                "[PRODUCT SAVE]",
                response
            );


            window.closeProductModal();


            notify(
                editing
                    ? "Produk berhasil diperbarui."
                    : "Produk berhasil ditambahkan."
            );


            await loadProducts();


        } catch (error) {

            console.error(
                "Save product error:",
                error
            );


            notify(
                error.message ||
                "Gagal menyimpan produk.",
                true
            );

        } finally {

            elements.saveButton.disabled =
                false;

            elements.saveButton.textContent =
                editing
                    ? "Simpan Perubahan"
                    : "Simpan Produk";

        }

    };


/* =========================================================
   EVENTS
========================================================= */

function setupEvents() {

    // Tombol tambah produk, tutup modal, dan cancel
    // sudah ditangani langsung oleh inline script di
    // products.html (window.openProductModal /
    // window.closeProductModal), jadi tidak perlu
    // di-attach ulang di sini.

    elements.searchInput
        .addEventListener(
            "input",
            () => {

                renderProducts(
                    products
                );

            }
        );


    elements.refreshButton
        .addEventListener(
            "click",
            async () => {

                elements.refreshButton
                    .classList.add(
                        "loading"
                    );

                try {

                    await loadProducts();

                } finally {

                    elements.refreshButton
                        .classList.remove(
                            "loading"
                        );

                }

            }
        );


    elements.productsList
        .addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        "[data-action]"
                    );


                if (!button) {
                    return;
                }


                const id =
                    button.dataset.id;


                const product =
                    products.find(
                        item =>
                            String(
                                item.id
                            ) ===
                            String(id)
                    );


                if (!product) {
                    return;
                }


                const action =
                    button.dataset.action;


                if (
                    action ===
                    "edit"
                ) {

                    openEdit(
                        product
                    );

                }


                if (
                    action ===
                    "delete"
                ) {

                    deleteProduct(
                        product
                    );

                }

            }
        );


    elements.logoutButton
        .addEventListener(
            "click",
            logout
        );


    elements.menuButton
        ?.addEventListener(
            "click",
            () => {

                elements.sidebar
                    ?.classList.toggle(
                        "open"
                    );

            }
        );


    elements.dashboardNav
        ?.addEventListener(
            "click",
            () => {

                window.location.href =
                    "/admin/dashboard/";

            }
        );


    elements.brandNav
        ?.addEventListener(
            "click",
            () => {

                window.location.href =
                    "/admin/brand/";

            }
        );


    elements.statisticsNav
        ?.addEventListener(
            "click",
            () => {

                window.location.href =
                    "/admin/statistics/";

            }
        );

}


/* =========================================================
   LOGOUT
========================================================= */

function logout() {

    const currentToken = sessionStorage.getItem(tokenKey);
    fetch("/api/admin/logout", {method:"POST", headers:{Authorization:`Bearer ${currentToken}`}}).catch(()=>{}).finally(()=>{
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);
        sessionStorage.removeItem("fydzstore_admin_role");
        sessionStorage.removeItem("fydzstore_admin_username");
        window.location.href = "/admin/";
    });

}


/* =========================================================
   LOADING
========================================================= */

function setLoading(
    state
) {

    if (!elements.loading) {
        return;
    }


    elements.loading.classList.toggle(
        "hidden",
        !state
    );

}


/* =========================================================
   TOAST
========================================================
   products.html sudah punya toast sendiri
   (window.showProductToast). Kita pakai itu supaya
   tidak ada dua elemen toast yang saling tumpang tindih.
======================================================== */

function notify(
    message,
    error = false
) {

    if (
        typeof window.showProductToast ===
        "function"
    ) {

        window.showProductToast(
            message,
            error
        );

        return;

    }


    if (!elements.toast) {

        console.log(
            message
        );

        return;

    }


    elements.toast.textContent =
        message;

    elements.toast.classList.toggle(
        "error",
        error
    );

    elements.toast.classList.add(
        "show"
    );


    clearTimeout(
        notify.timer
    );

    notify.timer =
        setTimeout(
            () => {

                elements.toast.classList.remove(
                    "show"
                );

            },
            3000
        );

}


/* =========================================================
   HELPERS
========================================================= */

function getCategory(
    product
) {

    return String(
        product?.category ||
        "lainnya"
    )
        .toLowerCase();

}


function formatNumber(
    value
) {

    const number =
        Number(value);


    if (
        !Number.isFinite(
            number
        )
    ) {

        return "0";

    }


    return number.toLocaleString(
        "id-ID"
    );

}


function formatPrice(
    value
) {

    const number =
        Number(value);


    if (
        !Number.isFinite(
            number
        )
    ) {

        return "Rp 0";

    }


    return (
        "Rp " +
        number.toLocaleString(
            "id-ID"
        )
    );

}


function normalizeMediaUrl(
    value
) {

    if (!value) {

        return "/assets__fydz-logo.svg";

    }


    const url =
        String(value)
            .trim();


    if (!url) {

        return "/assets__fydz-logo.svg";

    }


    if (
        /^data:/i.test(
            url
        )
    ) {

        return url;

    }


    if (
        /^https?:\/\//i.test(
            url
        )
    ) {

        return url;

    }


    return url.startsWith("/")
        ? url
        : "/" + url;

}


function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );

}


function escapeAttribute(
    value
) {

    return escapeHTML(
        value
    );

}