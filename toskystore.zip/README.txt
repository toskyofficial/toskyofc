Fydz Official Shop V12 - Vercel Mobile Flat

FIXES: local script paths, customer auth cookies, review auth sync, admin login/dashboard script paths, admin route rewrites.
Upload ALL files in this folder to the ROOT of the GitHub repository. Do not upload the ZIP itself.
