"use strict";

const state = {
    products: [],
    category: "all",
    search: "",
    sort: "default",
    favoritesOnly: false,
    favorites: JSON.parse(localStorage.getItem("fydz_favorites") || "[]")
};

let productsLoading;
let productGrid;
let emptyState;
let searchInput;
let menuToggle;
let navMenu;
let sortSelect;
let favoritesToggle;
let favoriteCount;
let toast;
let backTop;


document.addEventListener("DOMContentLoaded", () => {
    productsLoading = document.getElementById("productsLoading");
    productGrid = document.getElementById("productGrid");
    emptyState = document.getElementById("emptyState");
    searchInput = document.getElementById("searchInput");
    menuToggle = document.getElementById("menuToggle"); 
    navMenu = document.getElementById("navMenu");
    sortSelect = document.getElementById("sortSelect");
    favoritesToggle = document.getElementById("favoritesToggle");
    favoriteCount = document.getElementById("favoriteCount");
    toast = document.getElementById("toast");
    backTop = document.getElementById("backTop");
    
    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    setupEvents();
    saveFavorites();
    loadProducts();
});


/* =========================================================
   EVENTS
========================================================= */

function setupEvents() {
    if (searchInput) {
        searchInput.addEventListener("input",() => {
            state.search = searchInput.value.trim().toLowerCase();
            renderProducts();
            }
        );
    }

    document.querySelectorAll(".category-btn").forEach(
        button => {
            button.addEventListener(
                "click",() => {
                    document.querySelectorAll(".category-btn").forEach(
                        btn => {
                            btn.classList.remove("active");
                    });
                    button.classList.add("active");
                    state.category = button.dataset.category || "all";
                    renderProducts();
                }
            );
        }
    );


    if (sortSelect) {
        sortSelect.addEventListener("change", () => {
            state.sort = sortSelect.value;
            renderProducts();
        });
    }

    if (favoritesToggle) {
        favoritesToggle.addEventListener("click", () => {
            state.favoritesOnly = !state.favoritesOnly;
            favoritesToggle.classList.toggle("active", state.favoritesOnly);
            favoritesToggle.innerHTML = `${state.favoritesOnly ? "♥" : "♡"} Favorit <span id="favoriteCount">${state.favorites.length}</span>`;
            favoriteCount = document.getElementById("favoriteCount");
            renderProducts();
        });
    }

    document.addEventListener("keydown", event => {
        if (event.key === "/" && document.activeElement !== searchInput) {
            event.preventDefault();
            searchInput?.focus();
        }
    });

    window.addEventListener("scroll", () => {
        if (backTop) backTop.classList.toggle("show", window.scrollY > 500);
    }, {passive:true});

    if (backTop) backTop.addEventListener("click", () => window.scrollTo({top:0, behavior:"smooth"}));

    if (menuToggle && navMenu) {
        menuToggle.addEventListener(
            "click", () => {
                navMenu.classList.toggle(
                    "active"
                );
            }
        );

        navMenu.querySelectorAll("a").forEach(
            link => {
                link.addEventListener(
                    "click",() => {
                        navMenu.classList.remove(
                            "active"
                        );
                    }
                );
            }
        );
    }
}


/* =========================================================
   LOAD PRODUCTS
========================================================= */

async function loadProducts() {
    showLoading();

    if (productGrid) {
        productGrid.innerHTML = "";
    }

    if (emptyState) {
        emptyState.hidden = true;
    }

    try {
        const response = await fetch(
            "/api/product/list",{
                method: "GET",
                headers: {
                    Accept: "application/json"
                },
                cache: "no-store"
            }
        );

        if (!response.ok) {
            throw new Error(
                `Gagal mengambil produk (${response.status})`
            );
        }

        const result = await response.json();

        if (Array.isArray(result)) {
            state.products = result;
        } else if (
            Array.isArray(result?.data)
        ) {
            state.products = result.data;
        } else if (
            Array.isArray(result?.products)
        ) {
            state.products = result.products;
        } else {
            state.products = [];
        }

        hideLoading();
        renderProducts();
    } catch (error) {
        console.error(
            "Fydz Official Shop product error:",
            error
        );

        state.products = [];
        hideLoading();

        if (productGrid) {
            productGrid.innerHTML = `
                <div
                    class="empty-state"
                    style="grid-column:1/-1;"
                >
                    <strong>
                        Gagal memuat produk
                    </strong>

                    Silakan refresh halaman
                    dan coba lagi.
                </div>
            `;
        }
    } finally {
        hideLoading();
    }
}

function showLoading() {
    if (productsLoading) {
        productsLoading.hidden = false;
    }
}

function hideLoading() {
    if (productsLoading) {
        productsLoading.hidden = true;
    }
}

function getFilteredProducts() {
    let products = state.products.filter(product => {
        const category = String(product?.category || "").toLowerCase();
        const name = String(product?.name || "").toLowerCase();
        const description = String(product?.description || "").toLowerCase();
        const brand = String(product?.brandName || "").toLowerCase();
        const searchText = [name, description, brand, category].join(" ");
        const id = String(product?.id ?? "");
        const matchesCategory = state.category === "all" || category === state.category;
        const matchesSearch = !state.search || searchText.includes(state.search);
        const matchesFavorite = !state.favoritesOnly || state.favorites.includes(id);
        return matchesCategory && matchesSearch && matchesFavorite;
    });

    if (state.sort === "price-low") products.sort((a,b) => Number(a?.price||0) - Number(b?.price||0));
    if (state.sort === "price-high") products.sort((a,b) => Number(b?.price||0) - Number(a?.price||0));
    if (state.sort === "name") products.sort((a,b) => String(a?.name||"").localeCompare(String(b?.name||""), "id"));
    return products;
}

function saveFavorites() {
    localStorage.setItem("fydz_favorites", JSON.stringify(state.favorites));
    if (favoriteCount) favoriteCount.textContent = state.favorites.length;
}

function toggleFavorite(id, button) {
    id = String(id);
    const index = state.favorites.indexOf(id);
    if (index >= 0) {
        state.favorites.splice(index, 1);
        showToast("Produk dihapus dari favorit");
    } else {
        state.favorites.push(id);
        showToast("Produk disimpan ke favorit");
    }
    saveFavorites();
    if (button) {
        button.classList.toggle("active", state.favorites.includes(id));
        button.textContent = state.favorites.includes(id) ? "♥" : "♡";
    }
    if (state.favoritesOnly) renderProducts();
}

function showToast(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(showToast.timer);
    showToast.timer = setTimeout(() => toast.classList.remove("show"), 2200);
}

async function shareProduct(product) {
    const url = new URL(`/detail?id=${encodeURIComponent(product.id)}`, window.location.href).href;
    const title = product?.name || "Produk Fydz Official Shop";
    try {
        if (navigator.share) {
            await navigator.share({title, text:`${title} — Fydz Official Shop`, url});
            return;
        }
        await navigator.clipboard.writeText(url);
        showToast("Link produk berhasil disalin");
    } catch (error) {
        if (error?.name !== "AbortError") showToast("Link tidak bisa dibagikan");
    }
}

function renderProducts() {
    if (!productGrid) {
        return;
    }

    const products = getFilteredProducts();

    productGrid.innerHTML = "";

    if (emptyState) {
        emptyState.hidden = products.length !== 0;
    }

    if (products.length === 0) {
        return;
    }

    const fragment = document.createDocumentFragment();

    products.forEach(product => {
        const card = document.createElement("article");
        
        card.className = "product-card";

        const imageUrl = getThumbnail(product);
        const name = product?.name || "Produk";
        const category = product?.category || "Produk";
        const price = product?.price ?? 0;

        const description = product?.description || "Produk digital siap diproses dengan cepat.";
        const rating = Number(product?.rating || 0);
        const reviewCount = Number(product?.reviewCount || 0);
        const ratingText = reviewCount ? `★ ${rating.toFixed(1)} · ${reviewCount} ulasan` : "Belum ada ulasan";

        const productId = String(product?.id ?? "");
        const isFavorite = state.favorites.includes(productId);
        card.innerHTML = `
            <div class="product-image">
                ${
                    imageUrl ?
                        `
                            <img
                                src="${escapeAttribute(imageUrl)}"
                                alt="${escapeAttribute(name)}"
                                loading="lazy"
                                onerror="this.style.display='none';this.parentElement.querySelector('.product-image-placeholder').style.display='flex'"
                            >
                            <div class="product-image-placeholder" style="display:none">✦</div>
                        `
                        :
                        `
                            <div class="product-image-placeholder">✦</div>
                        `
                }
                <div class="product-overlay">
                    <span class="product-category">${escapeHTML(category)}</span>
                    <span class="product-mini-arrow">↗</span>
                </div>
                <div class="product-tools">
                    <button class="product-tool favorite-btn ${isFavorite ? "active" : ""}" type="button" aria-label="Simpan favorit">${isFavorite ? "♥" : "♡"}</button>
                    <button class="product-tool share-btn" type="button" aria-label="Bagikan produk">↗</button>
                </div>
            </div>

            <div class="product-content">
                <div class="product-name">${escapeHTML(name)}</div>
                <div class="product-brand">Fydz Official Shop • ${escapeHTML(category)}</div>
                <div class="product-desc">${escapeHTML(description)}</div>
                <div class="product-rating"><b>${escapeHTML(ratingText)}</b></div>
                <div class="product-bottom">
                    <div class="product-price">${formatPrice(price)}</div>
                    <button class="product-action" type="button">Beli Sekarang&nbsp; →</button>
                </div>
            </div>
        `;

        const favoriteBtn = card.querySelector(".favorite-btn");
        const shareBtn = card.querySelector(".share-btn");

        favoriteBtn?.addEventListener("click", event => {
            event.stopPropagation();
            toggleFavorite(productId, favoriteBtn);
        });

        shareBtn?.addEventListener("click", event => {
            event.stopPropagation();
            shareProduct(product);
        });

        const button = card.querySelector(
            ".product-action"
        );

        if (button) {
            button.addEventListener(
                "click",
                event => {
                    event.stopPropagation();
                    redirectToDetail(
                        product
                    );
                }
            );
        }

        card.addEventListener(
            "click",
            () => {
                redirectToDetail(
                    product
                );
            }
        );

        fragment.appendChild(card);
    });
    productGrid.appendChild(fragment);
}

function getThumbnail(product) {
    if (!product) {
        return "";
    }

    const thumbnail = product.thumbnailProduct;

    if (!thumbnail) {
        return "";
    }

    const value = String(thumbnail).trim();

    if (!value) {
        return "";
    }

    if (
        value.startsWith(
            "/thumbnail/"
        )
    ) {
        return value;
    }

    if (
        value.startsWith("http://") ||
        value.startsWith("https://") ||
        value.startsWith("//")
    ) {
        return value;
    }

    return `/thumbnail/${encodeURIComponent(
        value.replace(/^\/+/, "")
    )}`;
}

function redirectToDetail(product) {
    if (!product) {
        return;
    }

    const id = product.id;

    if (
        id === undefined ||
        id === null ||
        String(id).trim() === ""
    ) {
        console.error(
            "ID produk tidak ditemukan:",
            product
        );
        return;
    }

    const url = `/detail?id=${encodeURIComponent(id)}`;
    
    window.location.href = url;
}

function formatPrice(value) {
    const number = Number(value);

    if (!Number.isFinite(number)) {
        return "Harga tidak tersedia";
    }

    return new Intl.NumberFormat(
        "id-ID",
        {
            style: "currency",
            currency: "IDR",
            maximumFractionDigits: 0
        }
    ).format(number);
}

function escapeHTML(value) {
    return String(value ?? "")
    .replace(
        /&/g,
        "&amp;"
    )
    .replace(
        /</g,
        "&lt;"
    )
    .replace(
        />/g,
        "&gt;"
    )
    .replace(
        /"/g,
        "&quot;"
    )
    .replace(
        /'/g,
        "&#039;"
    );
}

function escapeAttribute(value) {
    return escapeHTML(value);
}

window.loadProducts = loadProducts;
window.redirectToDetail = redirectToDetail;