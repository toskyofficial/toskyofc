"use strict";


/* =========================================================
   STATE
========================================================= */

let product = null;


/* =========================================================
   DOM
========================================================= */

let loading;
let errorState;
let errorMessage;
let errorButton;

let productDetail;

let mainImage;
let galleryList;

let productCategory;
let productName;
let productBrand;
let productPrice;
let productDescription;

let productActions;

let metaCategory;
let metaId;

let menuToggle;
let navMenu;


/* =========================================================
   INIT
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        loading =
            document.getElementById(
                "loading"
            );

        errorState =
            document.getElementById(
                "errorState"
            );

        errorMessage =
            document.getElementById(
                "errorMessage"
            );

        errorButton =
            document.getElementById(
                "errorButton"
            );

        productDetail =
            document.getElementById(
                "productDetail"
            );

        mainImage =
            document.getElementById(
                "mainImage"
            );

        galleryList =
            document.getElementById(
                "galleryList"
            );

        productCategory =
            document.getElementById(
                "productCategory"
            );

        productName =
            document.getElementById(
                "productName"
            );

        productBrand =
            document.getElementById(
                "productBrand"
            );

        productPrice =
            document.getElementById(
                "productPrice"
            );

        productDescription =
            document.getElementById(
                "productDescription"
            );

        productActions =
            document.getElementById(
                "productActions"
            );

        metaCategory =
            document.getElementById(
                "metaCategory"
            );

        metaId =
            document.getElementById(
                "metaId"
            );

        menuToggle =
            document.getElementById(
                "menuToggle"
            );

        navMenu =
            document.getElementById(
                "navMenu"
            );


        const year =
            document.getElementById(
                "year"
            );


        if (year) {
            year.textContent =
                new Date().getFullYear();
        }


        setupEvents();

        loadProduct();
    }
);


/* =========================================================
   EVENTS
========================================================= */

function setupEvents() {

    if (errorButton) {

        errorButton.addEventListener(
            "click",
            () => {

                window.location.href =
                    "//index.html#produk";
            }
        );
    }


    if (
        menuToggle &&
        navMenu
    ) {

        menuToggle.addEventListener(
            "click",
            () => {

                navMenu.classList.toggle(
                    "active"
                );
            }
        );


        navMenu
            .querySelectorAll("a")
            .forEach(link => {

                link.addEventListener(
                    "click",
                    () => {

                        navMenu.classList.remove(
                            "active"
                        );
                    }
                );

            });
    }
}


/* =========================================================
   GET PRODUCT ID
========================================================= */

function getProductId() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    return params.get("id");
}


/* =========================================================
   LOAD PRODUCT
========================================================= */

async function loadProduct() {

    const id =
        getProductId();


    if (!id) {

        showError(
            "ID produk tidak ditemukan di URL."
        );

        return;
    }


    showLoading();


    try {

        const response =
            await fetch(
                `/api/product/detail?id=${encodeURIComponent(id)}`,
                {
                    method: "GET",

                    headers: {
                        Accept:
                            "application/json"
                    },

                    cache: "no-store"
                }
            );


        if (!response.ok) {

            throw new Error(
                `Produk tidak ditemukan (${response.status})`
            );
        }


        const result =
            await response.json();


        /*
         * Support:
         *
         * object
         * { data: object }
         * { product: object }
         */

        if (
            result &&
            !Array.isArray(result) &&
            typeof result === "object"
        ) {

            if (
                result.data &&
                typeof result.data === "object" &&
                !Array.isArray(result.data)
            ) {

                product =
                    result.data;

            } else if (
                result.product &&
                typeof result.product === "object" &&
                !Array.isArray(result.product)
            ) {

                product =
                    result.product;

            } else {

                product =
                    result;
            }

        } else {

            throw new Error(
                "Format data produk tidak valid."
            );
        }


        if (!product.id) {

            throw new Error(
                "Data produk tidak memiliki ID."
            );
        }


        /*
         * Ambil brand.
         *
         * Kalau gagal, halaman produk
         * tetap ditampilkan.
         */

        const brandName =
            await getBrandName(
                product.brandID
            );


        renderProduct(
            product,
            brandName
        );


        hideLoading();


    } catch (error) {

        console.error(
            "Fydz Official Shop detail error:",
            error
        );


        showError(
            error.message ||
            "Gagal memuat detail produk."
        );
    }
}


/* =========================================================
   BRAND
========================================================= */

async function getBrandName(
    brandID
) {

    if (!brandID) {
        return "";
    }


    try {

        const response =
            await fetch(
                `/api/product/brand/detail?id=${encodeURIComponent(brandID)}`,
                {
                    method: "GET",

                    headers: {
                        Accept:
                            "application/json"
                    },

                    cache: "no-store"
                }
            );


        if (!response.ok) {
            return "";
        }


        const result =
            await response.json();


        const brand =
            result?.data ||
            result?.brand ||
            result;


        if (!brand) {
            return "";
        }


        if (
            typeof brand === "string"
        ) {

            return brand;
        }


        return (
            brand.name ||
            brand.brandName ||
            brand.title ||
            ""
        );

    } catch (error) {

        console.warn(
            "Brand tidak dapat dimuat:",
            error
        );

        return "";
    }
}


/* =========================================================
   RENDER
========================================================= */

function renderProduct(
    product,
    brandName
) {

    const name =
        product.name ||
        "Produk";


    const category =
        product.category ||
        "Produk";


    const price =
        product.price ??
        0;


    const description =
        product.description ||
        "Tidak ada deskripsi produk.";


    /*
     * =====================================================
     * PRODUCT STATISTICS
     * =====================================================
     *
     * Dipakai oleh statistics tracking script.
     *
     * Contoh hasil:
     *
     * document.body.dataset.productId
     * -> 534479544b524282
     *
     * document.body.dataset.productName
     * -> Kaos Sablon
     */

    if (document.body) {

        document.body.dataset.productId =
            String(product.id);

        document.body.dataset.productName =
            String(name);

        console.log(
            "[FYDZSTORE PRODUCT TRACKING]",
            {
                productId:
                    document.body.dataset.productId,

                productName:
                    document.body.dataset.productName
            }
        );
    }


    /*
     * Render informasi produk.
     */

    productCategory.textContent =
        category;


    productName.textContent =
        name;


    productBrand.textContent =
        brandName
            ? `Brand: ${brandName}`
            : "Brand lokal";


    productPrice.textContent =
        formatPrice(price);


    productDescription.textContent =
        description;


    metaCategory.textContent =
        category;


    metaId.textContent =
        product.id;


    renderGallery(
        product
    );


    renderActions(
        product
    );


    productDetail.hidden =
        false;
}


/* =========================================================
   GALLERY
========================================================= */

function renderGallery(
    product
) {

    galleryList.innerHTML =
        "";


    /*
     * API:
     *
     * thumbnailProduct
     * imagesProduct
     */

    const thumbnail =
        product.thumbnailProduct;


    let images =
        Array.isArray(
            product.imagesProduct
        )
            ? [
                ...product.imagesProduct
            ]
            : [];


    /*
     * Thumbnail selalu menjadi
     * gambar pertama.
     */

    if (
        thumbnail &&
        !images.includes(
            thumbnail
        )
    ) {

        images.unshift(
            thumbnail
        );
    }


    /*
     * Tidak ada gambar.
     */

    if (images.length === 0) {

        mainImage.removeAttribute(
            "src"
        );

        mainImage.alt =
            "Produk";

        return;
    }


    /*
     * Main image.
     */

    const firstImage =
        normalizeMediaUrl(
            images[0]
        );


    mainImage.src =
        firstImage;

    mainImage.alt =
        product.name ||
        "Produk";


    /*
     * Thumbnail gallery.
     */

    images.forEach(
        (image, index) => {

            const url =
                normalizeMediaUrl(
                    image
                );


            if (!url) {
                return;
            }


            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "gallery-item";


            if (index === 0) {

                button.classList.add(
                    "active"
                );
            }


            button.innerHTML = `
                <img
                    src="${escapeAttribute(url)}"
                    alt="${escapeAttribute(
                        product.name ||
                        "Produk"
                    )}"
                    loading="lazy"
                >
            `;


            button.addEventListener(
                "click",
                () => {

                    mainImage.src =
                        url;


                    galleryList
                        .querySelectorAll(
                            ".gallery-item"
                        )
                        .forEach(
                            item => {

                                item.classList.remove(
                                    "active"
                                );
                            }
                        );


                    button.classList.add(
                        "active"
                    );
                }
            );


            galleryList.appendChild(
                button
            );
        }
    );
}


/* =========================================================
   MEDIA URL
========================================================= */

function normalizeMediaUrl(
    value
) {

    if (!value) {
        return "";
    }


    const url =
        String(value).trim();


    if (!url) {
        return "";
    }


    /*
     * Absolute URL.
     */

    if (
        url.startsWith(
            "http://"
        ) ||
        url.startsWith(
            "https://"
        ) ||
        url.startsWith(
            "//"
        )
    ) {

        return url;
    }


    /*
     * API:
     *
     * /thumbnail/...
     * /media/...
     */

    if (
        url.startsWith(
            "/thumbnail/"
        ) ||
        url.startsWith(
            "/media/"
        )
    ) {

        return url;
    }


    /*
     * Fallback.
     */

    return `/${url.replace(
        /^\/+/,
        ""
    )}`;
}


/* =========================================================
   ACTIONS
========================================================= */

function renderActions(product) {
    productActions.innerHTML = "";

    const buy = document.createElement("button");
    buy.type = "button";
    buy.className = "action-button whatsapp";
    buy.textContent = "🛒 Beli Sekarang";
    buy.addEventListener("click", () => openOrderModal(product));
    productActions.appendChild(buy);

    const orderInfo = document.createElement("div");
    orderInfo.className = "order-note";
    orderInfo.textContent = "Isi data order terlebih dahulu. Order akan tersimpan di panel developer sebelum dilanjutkan ke WhatsApp.";
    productActions.appendChild(orderInfo);

    const instagram = getInstagramLink(product);
    if (instagram) {
        const link = document.createElement("a");
        link.href = instagram;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.className = "action-button instagram";
        link.textContent = "Instagram";
        productActions.appendChild(link);
    }
}

function formatRupiah(value) {
    return `Rp${Number(value || 0).toLocaleString("id-ID")}`;
}

function normalizeWhatsAppNumber(value) {
    let number = String(value || "").replace(/\D/g, "");
    if (number.startsWith("0")) number = "62" + number.slice(1);
    else if (number.startsWith("8")) number = "62" + number;
    return number;
}

async function openOrderModal(item) {
    product = item;
    const modal = document.getElementById("orderModal");
    if (!modal) return;
    modal.hidden = false;
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    document.getElementById("orderProductName").textContent = item?.name || "Produk";
    document.getElementById("orderUnitPrice").textContent = formatRupiah(item?.price);
    updateOrderTotal();
    const error = document.getElementById("orderError");
    error.style.display = "none";
    try {
        const token = localStorage.getItem("fydz_customer_token") || sessionStorage.getItem("fydz_customer_token");
        const r = await fetch("/api/auth/me", {cache:"no-store", credentials:"include", headers: token ? {Authorization:`Bearer ${token}`} : {}});
        const d = await r.json();
        if (d?.user) {
            const name = document.getElementById("orderBuyerName");
            if (name && !name.value) name.value = d.user.name || d.user.username || "";
        }
    } catch {}
}

function closeOrderModal() {
    const modal = document.getElementById("orderModal");
    if (!modal) return;
    modal.hidden = true;
    modal.setAttribute("aria-hidden", "true");
    document.body.style.overflow = "";
}

function updateOrderTotal() {
    const qty = Math.max(1, Math.min(99, Number(document.getElementById("orderQuantity")?.value || 1)));
    const total = Number(product?.price || 0) * qty;
    const totalEl = document.getElementById("orderTotalPrice");
    if (totalEl) totalEl.textContent = formatRupiah(total);
}

async function submitOrder(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const button = document.getElementById("orderSubmit");
    const error = document.getElementById("orderError");
    const data = new FormData(form);
    const payload = {
        productId: product?.id,
        productName: product?.name,
        quantity: Number(data.get("quantity") || 1),
        buyerName: String(data.get("buyerName") || "").trim(),
        whatsapp: String(data.get("whatsapp") || "").trim(),
        note: String(data.get("note") || "").trim()
    };
    error.style.display = "none";
    if (!payload.productId || !payload.buyerName || !payload.whatsapp) {
        error.textContent = "Nama, nomor WhatsApp, dan produk wajib diisi.";
        error.style.display = "block";
        return;
    }
    button.disabled = true;
    button.textContent = "Menyimpan order...";
    try {
        const token = localStorage.getItem("fydz_customer_token") || sessionStorage.getItem("fydz_customer_token");
        const response = await fetch("/api/orders", {method:"POST",credentials:"include",headers:{"Content-Type":"application/json",...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify(payload)});
        const result = await response.json();
        if (!response.ok) throw new Error(result?.error || "Gagal membuat order.");
        const number = normalizeWhatsAppNumber(product?.contact?.whatsapp || "6283120264665");
        const total = Number(result.order?.totalPrice || Number(product?.price || 0) * payload.quantity);
        const message = `Halo Fydz Official, saya ingin order *${product?.name || "Produk"}*.
Order ID: ${result.order?.id || "-"}
Nama: ${payload.buyerName}
Jumlah: ${payload.quantity}
Harga satuan: ${formatRupiah(product?.price)}
Total: ${formatRupiah(total)}${payload.note ? `\nCatatan: ${payload.note}` : ""}`;
        closeOrderModal();
        window.open(`https://wa.me/${number}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
    } catch (e) {
        error.textContent = e.message || "Gagal membuat order.";
        error.style.display = "block";
    } finally {
        button.disabled = false;
        button.textContent = "Simpan Order & Lanjut WhatsApp →";
    }
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("orderClose")?.addEventListener("click", closeOrderModal);
    document.getElementById("orderModal")?.addEventListener("click", (event) => { if (event.target.id === "orderModal") closeOrderModal(); });
    document.getElementById("orderQuantity")?.addEventListener("input", updateOrderTotal);
    document.getElementById("orderForm")?.addEventListener("submit", submitOrder);
    document.addEventListener("keydown", (event) => { if (event.key === "Escape") closeOrderModal(); });
});

/* =========================================================
   WHATSAPP
========================================================= */

function getWhatsAppLink(
    product
) {

    let number =
        product?.contact?.whatsapp ||
        "6283120264665";


    if (!number) {
        return "";
    }


    number =
        String(number)
            .replace(
                /\D/g,
                ""
            );


    /*
     * 08xxxxxxxx
     * ->
     * 628xxxxxxxx
     */

    if (
        number.startsWith("0")
    ) {

        number =
            "62" +
            number.slice(1);

    } else if (
        number.startsWith("8")
    ) {

        number =
            "62" +
            number;
    }


    if (!number) {
        return "";
    }


    const productName =
        product?.name ||
        "Produk";

    const price =
        product?.price ??
        0;

    const message =
        `Halo Fydz Official, saya ingin order *${productName}*.\nHarga: ${formatPrice(price)}\nSaya ingin mengetahui proses ordernya.`;

    return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}


/* =========================================================
   INSTAGRAM
========================================================= */

function getInstagramLink(
    product
) {

    let username =
        product?.contact?.instagram ||
        "";


    if (!username) {
        return "";
    }


    username =
        String(username)
            .trim()
            .replace(
                /^@/,
                ""
            );


    if (!username) {
        return "";
    }


    if (
        username.startsWith(
            "http://"
        ) ||
        username.startsWith(
            "https://"
        )
    ) {

        return username;
    }


    return `https://instagram.com/${username}`;
}


/* =========================================================
   LOADING
========================================================= */

function showLoading() {

    if (loading) {

        loading.hidden =
            false;
    }


    if (errorState) {

        errorState.hidden =
            true;
    }


    if (productDetail) {

        productDetail.hidden =
            true;
    }
}


function hideLoading() {

    if (loading) {

        loading.hidden =
            true;
    }
}


/* =========================================================
   ERROR
========================================================= */

function showError(
    message
) {

    hideLoading();


    if (productDetail) {

        productDetail.hidden =
            true;
    }


    if (errorMessage) {

        errorMessage.textContent =
            message;
    }


    if (errorState) {

        errorState.hidden =
            false;
    }
}


/* =========================================================
   PRICE
========================================================= */

function formatPrice(
    value
) {

    const number =
        Number(value);


    if (
        !Number.isFinite(
            number
        )
    ) {

        return "Harga tidak tersedia";
    }


    return new Intl.NumberFormat(
        "id-ID",
        {
            style: "currency",
            currency: "IDR",
            maximumFractionDigits: 0
        }
    ).format(number);
}


/* =========================================================
   HTML ESCAPE
========================================================= */

function escapeHTML(
    value
) {

    return String(
        value ?? ""
    )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


function escapeAttribute(
    value
) {

    return escapeHTML(
        value
    );
}