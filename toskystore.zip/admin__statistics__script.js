"use strict";

/* =========================================================
   CONFIG
========================================================= */
const API = {
    // API List Produk (Public)
    list: "/api/product/list",
    // API Statistik (Admin Protected)
    stats: "/api/admin/statistics", 
};

const tokenKey = "fydzstore_admin_token";
const emailKey = "fydzstore_admin_email";

/* =========================================================
   AUTH CHECK
========================================================= */
const token = sessionStorage.getItem(tokenKey);

if (!token) {
    window.location.href = "/admin/";
    throw new Error("Admin belum login.");
}

const adminEmailValue = sessionStorage.getItem(emailKey) || "-";

/* =========================================================
   STATE
========================================================= */
let statsData = [];
let filteredStats = [];

/* =========================================================
   DOM
========================================================= */
const sidebar = document.getElementById("sidebar");
const menuButton = document.getElementById("menuButton");
const statsGrid = document.getElementById("statsGrid");
const searchInput = document.getElementById("searchInput");
const refreshButton = document.getElementById("refreshButton");

const totalVisitsEl = document.getElementById("totalVisits");
const topProductEl = document.getElementById("topProduct");

const adminEmail = document.getElementById("adminEmail");
const adminAvatar = document.getElementById("adminAvatar");
const logoutButton = document.getElementById("logoutButton");

/* =========================================================
   API REQUEST
========================================================= */
function authHeaders(withJsonType = true) {
    const headers = {
        "Authorization": `Bearer ${token}`,
        "Accept": "application/json"
    };
    if (withJsonType) {
        headers["Content-Type"] = "application/json";
    }
    return headers;
}

async function request(url, options = {}) {
    const response = await fetch(url, {
        ...options,
        headers: {
            ...authHeaders(),
            ...(options.headers || {})
        }
    });

    if (response.status === 401 || response.status === 403) {
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);
        window.location.href = "/admin/";
        throw new Error("Sesi admin sudah tidak valid.");
    }

    let data = null;
    try {
        data = await response.json();
    } catch {
        data = null;
    }

    if (!response.ok) {
        throw new Error(data?.message || data?.error || `Request gagal (${response.status})`);
    }

    return data;
}

function extractArray(data) {
    if (Array.isArray(data)) return data;
    if (Array.isArray(data?.data)) return data.data;
    if (Array.isArray(data?.products)) return data.products;
    return [];
}

/* =========================================================
   UTILITIES
========================================================= */
function escapeHTML(value) {
    return String(value ?? "")
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function formatNumber(value) {
    const num = Number(value);
    if (!Number.isFinite(num)) return "0";
    return num.toLocaleString("id-ID");
}

function normalizeMediaUrl(value) {
    if (!value) return "/assets__fydz-logo.svg";
    const url = String(value).trim();
    if (!url) return "/assets__fydz-logo.svg";
    if (/^data:/i.test(url)) return url;
    if (/^https?:\/\//i.test(url)) return url;
    return url.startsWith("/") ? url : "/" + url;
}

/* =========================================================
   LOAD STATS (MERGE DATA PRODUCT & STATISTICS)
========================================================= */
async function loadStats() {
    statsGrid.innerHTML = `<div class="empty-state">Memuat data statistik...</div>`;
    refreshButton.disabled = true;
    refreshButton.textContent = "Memuat...";

    try {
        const [productRes, statsRes] = await Promise.all([
            request(API.list),
            request(API.stats)
        ]);

        const products = extractArray(productRes);
        
        // Ambil array products dari stats API yang baru kita tambahkan
        const productsStatsArray = Array.isArray(statsRes?.products) ? statsRes.products : [];
        
        // Update Total Summary global 
        totalVisitsEl.textContent = formatNumber(statsRes?.visitors?.total || 0);

        // Gabungkan produk dengan data jumlah views
        statsData = products.map(product => {
            // Kita cocokkan ID produk asli dengan ID yang ada di 'products' (stats API)
            const matchStat = productsStatsArray.find(p => String(p.id) === String(product.id));
            
            return {
                ...product,
                views: matchStat ? matchStat.views : 0
            };
        });

        // Urutkan berdasarkan yang paling banyak dikunjungi (Descending)
        statsData.sort((a, b) => b.views - a.views);

        // Update Top Product text
        if (statsData.length > 0 && statsData[0].views > 0) {
            topProductEl.textContent = escapeHTML(statsData[0].name);
        } else {
            topProductEl.textContent = "Belum ada interaksi";
        }

        applySearch();

    } catch (error) {
        console.error("[STATS LOAD ERROR]", error);
        statsGrid.innerHTML = `
            <div class="empty-state">
                <div style="font-weight:700; margin-bottom:5px;">Gagal memuat statistik.</div>
                <div style="font-size:10px;">${escapeHTML(error.message)}</div>
            </div>
        `;
    } finally {
        refreshButton.disabled = false;
        refreshButton.textContent = "↻ Refresh";
    }
}

/* =========================================================
   SEARCH & RENDER
========================================================= */
function applySearch() {
    const keyword = String(searchInput.value || "").trim().toLowerCase();

    if (!keyword) {
        filteredStats = [...statsData];
    } else {
        filteredStats = statsData.filter(item => {
            const name = String(item.name || "").toLowerCase();
            const category = String(item.category || "").toLowerCase();
            return name.includes(keyword) || category.includes(keyword);
        });
    }

    renderStats();
}

function renderStats() {
    if (filteredStats.length === 0) {
        statsGrid.innerHTML = `
            <div class="empty-state">
                ${searchInput.value.trim() ? "Tidak ada produk yang cocok." : "Belum ada produk."}
            </div>
        `;
        return;
    }

    statsGrid.innerHTML = filteredStats.map(item => createStatCard(item)).join("");
}

function createStatCard(item) {
    const imgUrl = normalizeMediaUrl(item.thumbnailProduct || item.thumbnail);
    const views = Number(item.views) || 0;
    const category = item.category || "General";

    return `
        <div class="stat-card">
            <img class="stat-card-img" src="${escapeHTML(imgUrl)}" alt="${escapeHTML(item.name)}" onerror="this.src='/assets__fydz-logo.svg'">
            <div class="stat-card-body">
                <div class="stat-category">${escapeHTML(category)}</div>
                <div class="stat-title">${escapeHTML(item.name || "Produk Tanpa Nama")}</div>
                <div class="stat-id">ID: ${escapeHTML(item.id || "-")}</div>
                
                <div class="stat-views">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                    ${formatNumber(views)} Kunjungan
                </div>
            </div>
        </div>
    `;
}

/* =========================================================
   NAVIGATION & SIDEBAR
========================================================= */
function goTo(path) {
    window.location.href = path;
}

document.getElementById("dashboardNav")?.addEventListener("click", () => goTo("/admin/dashboard/"));
document.getElementById("productNav")?.addEventListener("click", () => goTo("/admin/product/"));
document.getElementById("brandNav")?.addEventListener("click", () => goTo("/admin/brand/"));
document.getElementById("statisticsNav")?.addEventListener("click", () => {
    if(window.innerWidth <= 900) { sidebar?.classList.remove("open"); }
});

menuButton?.addEventListener("click", () => {
    sidebar.classList.toggle("open");
});

/* =========================================================
   LOGOUT
========================================================= */
logoutButton?.addEventListener("click", () => {
    const currentToken = sessionStorage.getItem(tokenKey);
    fetch("/api/admin/logout", {method:"POST", headers:{Authorization:`Bearer ${currentToken}`}}).catch(()=>{}).finally(()=>{
        sessionStorage.removeItem(tokenKey);
        sessionStorage.removeItem(emailKey);
        sessionStorage.removeItem("fydzstore_admin_role");
        sessionStorage.removeItem("fydzstore_admin_username");
        window.location.href = "/admin/";
    });
});

/* =========================================================
   EVENTS BINDING
========================================================= */
refreshButton?.addEventListener("click", loadStats);
searchInput?.addEventListener("input", applySearch);

/* =========================================================
   INIT
========================================================= */
function init() {
    adminEmail.textContent = adminEmailValue;
    adminAvatar.textContent = adminEmailValue.charAt(0).toUpperCase();

    loadStats();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
} else {
    init();
}