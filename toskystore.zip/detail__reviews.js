"use strict";
let currentProductId = null;
const CUSTOMER_TOKEN_KEY="fydz_customer_token";
function reviewAuthHeaders(){const t=localStorage.getItem(CUSTOMER_TOKEN_KEY)||sessionStorage.getItem(CUSTOMER_TOKEN_KEY);return t?{Authorization:`Bearer ${t}`}:{}}
let selectedRating = 0;
function stars(n){n=Number(n||0);return "★★★★★".split("").map((s,i)=>i<n?"★":"☆").join("");}
function escapeReview(v){return String(v??"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;");}
function formatReviewDate(v){try{return new Intl.DateTimeFormat("id-ID",{dateStyle:"medium",timeStyle:"short"}).format(new Date(v));}catch{return "";}}
async function loadReviews(){
 currentProductId=new URLSearchParams(location.search).get("id"); if(!currentProductId)return;
 try{const r=await fetch(`/api/reviews?productId=${encodeURIComponent(currentProductId)}`,{cache:"no-store",credentials:"include"});const d=await r.json();if(!r.ok)throw new Error(d.error||"Gagal memuat review");document.getElementById("reviewAverage").textContent=Number(d.average||0).toFixed(1);document.getElementById("reviewAverageStars").textContent=stars(Math.round(Number(d.average||0)));document.getElementById("reviewCount").textContent=d.count?`${d.count} ulasan terverifikasi`:`Belum ada ulasan`;
 const list=document.getElementById("reviewList");if(!d.reviews?.length){list.innerHTML='<div class="review-empty">Belum ada review. Jadilah yang pertama memberikan testimoni.</div>';return;}list.innerHTML=d.reviews.map(r=>`<article class="review-card-v3"><div class="review-user"><img src="${escapeReview(r.user?.avatar||"/assets__fydz-logo.svg")}" onerror="this.src='/assets__fydz-logo.svg'" alt=""><div><b>${escapeReview(r.user?.name||"Customer")}</b><span class="review-date">${"Akun Fydz Official Shop"} • ${escapeReview(formatReviewDate(r.createdAt))}</span></div></div><div class="rating-stars" style="font-size:13px;margin-top:8px">${stars(r.rating)}</div><p class="review-comment">${escapeReview(r.comment)}</p></article>`).join("");
 }catch(e){document.getElementById("reviewList").innerHTML='<div class="review-empty">Review belum bisa dimuat.</div>';console.error(e);}
}
function syncReviewAuth(){const user=window.FydzAuth?.getUser?.();const prompt=document.getElementById("reviewLoginPrompt");const form=document.getElementById("reviewForm");if(user){prompt.hidden=true;form.hidden=false;}else{prompt.hidden=false;form.hidden=true;}}
document.addEventListener("DOMContentLoaded",()=>{
 document.querySelectorAll("#starPicker button").forEach(btn=>btn.addEventListener("click",()=>{selectedRating=Number(btn.dataset.rating);document.querySelectorAll("#starPicker button").forEach(x=>x.classList.toggle("active",Number(x.dataset.rating)<=selectedRating));}));
 document.getElementById("reviewLoginBtn")?.addEventListener("click",()=>{if(window.FydzAuth?.open)window.FydzAuth.open();else window.location.href="/?login=1";});
 document.getElementById("reviewForm")?.addEventListener("submit",async e=>{e.preventDefault();if(!selectedRating)return alert("Pilih rating bintang dulu.");const comment=document.getElementById("reviewComment").value.trim();if(comment.length<3)return alert("Komentar minimal 3 karakter.");const r=await fetch("/api/reviews",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json",...reviewAuthHeaders()},body:JSON.stringify({productId:currentProductId,rating:selectedRating,comment})});const d=await r.json();if(!r.ok)return alert(d.error||"Gagal mengirim review");document.getElementById("reviewComment").value="";selectedRating=0;document.querySelectorAll("#starPicker button").forEach(x=>x.classList.remove("active"));await loadReviews();alert("Review berhasil dikirim!");});
 syncReviewAuth();
 loadReviews();
 window.addEventListener("fydz-auth-ready",syncReviewAuth);
});
